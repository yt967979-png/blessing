--
-- PostgreSQL database dump
--

\restrict 4GknV6yGFDerkH9dWfKhdEa1pQ5MskvrDdlFo02LrRTGUfZTcodwySymuZ0qVe5

-- Dumped from database version 16.14 (Ubuntu 16.14-1.pgdg22.04+1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notify_books_changed(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.notify_books_changed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_payload text;
  v_mrp numeric;
  v_sale numeric;
  v_price numeric;
  v_discount int;
  v_instock boolean;
  v_stock int;
BEGIN
  IF (TG_OP = 'DELETE') THEN
    v_payload := json_build_object(
      'type', 'CATALOG_CHANGED',
      'bookIds', json_build_array(OLD.id),
      'timestamp', (extract(epoch from now())*1000)::bigint
    )::text;
    PERFORM pg_notify('stock_changed', v_payload);
    RETURN OLD;
  END IF;

  v_mrp := COALESCE(NEW.price, 0);
  v_sale := CASE 
    WHEN NEW.discount_price IS NOT NULL AND NEW.discount_price > 0 AND NEW.discount_price < v_mrp 
    THEN NEW.discount_price 
    ELSE v_mrp 
  END;
  v_price := v_sale;
  v_discount := CASE 
    WHEN v_mrp > 0 AND v_price < v_mrp 
    THEN ROUND(((v_mrp - v_price) / v_mrp) * 100) 
    ELSE 0 
  END;
  v_stock := GREATEST(0, COALESCE(NEW.stock, 0));
  v_instock := (v_stock > 0 AND COALESCE(NEW.status, 'published') = 'published');

  -- 1. Direct memory push: price & stock update instantly in client state (<50ms, 0 HTTP delay)
  v_payload := json_build_object(
    'type', 'STOCK_CHANGED',
    'books', json_build_array(
      json_build_object(
        'id', NEW.id,
        'stock', v_stock,
        'status', COALESCE(NEW.status, 'published'),
        'inStock', v_instock,
        'price', v_price,
        'mrp', v_mrp,
        'discount', v_discount
      )
    ),
    'timestamp', (extract(epoch from now())*1000)::bigint
  )::text;
  PERFORM pg_notify('stock_changed', v_payload);

  -- 2. Full catalog sync: handles new books, title, image, badge changes
  PERFORM pg_notify('stock_changed', json_build_object(
    'type', 'CATALOG_CHANGED',
    'bookIds', json_build_array(NEW.id),
    'timestamp', (extract(epoch from now())*1000)::bigint
  )::text);

  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abandoned_carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.abandoned_carts (
    id character varying(64) NOT NULL,
    user_id character varying(255),
    phone character varying(20) NOT NULL,
    name character varying(255),
    cart_json text NOT NULL,
    reminded boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: addresses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.addresses (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    full_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    alternate_phone character varying(20),
    address_line1 text NOT NULL,
    address_line2 text,
    city character varying(255) NOT NULL,
    district character varying(255),
    state character varying(255) DEFAULT 'Tamil Nadu'::character varying,
    country character varying(255) DEFAULT 'India'::character varying,
    pincode character varying(50) NOT NULL,
    landmark character varying(255),
    is_default boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    near_landmark character varying(255)
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id character varying(255) NOT NULL,
    actor_id character varying(255),
    action character varying(255) NOT NULL,
    target_type character varying(100),
    target_id character varying(255),
    details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(100),
    user_agent text
);


--
-- Name: book_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.book_images (
    id character varying(255) NOT NULL,
    book_id character varying(255),
    image_url text NOT NULL,
    display_order integer DEFAULT 0
);


--
-- Name: books; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.books (
    id character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    isbn character varying(100),
    author character varying(255) DEFAULT 'Blessing Editorial Board'::character varying,
    publisher character varying(255) DEFAULT 'Blessing Pathway Education'::character varying,
    edition character varying(50) DEFAULT '2026 Edition'::character varying,
    language character varying(50) DEFAULT 'Tamil / English'::character varying,
    semester character varying(50),
    department character varying(50),
    subject character varying(100),
    category_id character varying(255),
    description text,
    price numeric NOT NULL,
    discount_price numeric,
    stock integer DEFAULT 50,
    pages integer DEFAULT 240,
    weight character varying(50) DEFAULT '400g'::character varying,
    cover_image text,
    status character varying(50) DEFAULT 'published'::character varying,
    featured boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    badge character varying(100) DEFAULT ''::character varying,
    sample_pdf_url text,
    combo_subjects jsonb DEFAULT '[]'::jsonb,
    stock_tamil integer,
    stock_english integer,
    is_coming_soon boolean DEFAULT false
);


--
-- Name: cart; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart (
    id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cart_items (
    id character varying(255) NOT NULL,
    cart_id character varying(255),
    book_id character varying(255),
    quantity integer DEFAULT 1,
    price numeric NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    image text,
    parent_category character varying(255),
    status character varying(50) DEFAULT 'active'::character varying
);


--
-- Name: checkout_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkout_sessions (
    id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    razorpay_order_id character varying(255) NOT NULL,
    hold_group_id character varying(255),
    status character varying(50) DEFAULT 'PAYMENT_PENDING'::character varying,
    cart_snapshot jsonb NOT NULL,
    price_snapshot jsonb NOT NULL,
    shipping_address jsonb NOT NULL,
    subtotal numeric NOT NULL,
    discount numeric DEFAULT 0,
    shipping_fee numeric DEFAULT 0,
    total_amount numeric NOT NULL,
    coupon_code character varying(50),
    coupon_id character varying(255),
    order_id character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    source character varying(50) DEFAULT 'website'::character varying
);


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: contact_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_submissions (
    id integer NOT NULL,
    contact_id character varying(100),
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50) NOT NULL,
    subject character varying(255),
    message text NOT NULL,
    status character varying(50) DEFAULT 'unread'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: contact_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_submissions_id_seq OWNED BY public.contact_submissions.id;


--
-- Name: coupon_redemptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupon_redemptions (
    id character varying(255) NOT NULL,
    coupon_id character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    order_id character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: coupons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.coupons (
    id character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    discount_type character varying(20) DEFAULT 'percentage'::character varying NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    min_cart_qty integer DEFAULT 4,
    min_order_amount numeric(10,2) DEFAULT 0,
    max_discount_amount numeric(10,2),
    max_uses integer DEFAULT 10000,
    used_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    title character varying(255),
    show_on_hero boolean DEFAULT false
);


--
-- Name: courier_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.courier_tracking (
    id character varying(255) NOT NULL,
    order_id character varying(255),
    awb_number character varying(255),
    docket_number character varying(255),
    status character varying(255),
    current_status character varying(255),
    location character varying(255),
    remarks text,
    event_time timestamp without time zone,
    courier_name character varying(100) DEFAULT 'ST Courier Express'::character varying,
    origin_hub character varying(255),
    destination_hub character varying(255),
    estimated_delivery character varying(255),
    scraped_events jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: email_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_otps (
    id character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    otp character varying(10) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: failed_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_webhook_events (
    id character varying(255) NOT NULL,
    event_id character varying(255),
    event_type character varying(100),
    payload jsonb,
    error_message text,
    retry_count integer DEFAULT 0,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.faqs (
    id character varying(255) NOT NULL,
    question text NOT NULL,
    answer text NOT NULL,
    display_order integer DEFAULT 0,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: invoice_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_sequences (
    financial_year character varying(10) NOT NULL,
    last_number integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: job_heartbeats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_heartbeats (
    job_name character varying(100) NOT NULL,
    last_run_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'ok'::character varying,
    duration_ms integer DEFAULT 0,
    last_error text,
    details jsonb,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(50) DEFAULT 'info'::character varying,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id character varying(255) NOT NULL,
    order_id character varying(255),
    book_id character varying(255),
    book_title character varying(255) NOT NULL,
    book_price numeric NOT NULL,
    quantity integer NOT NULL,
    subtotal numeric NOT NULL,
    medium character varying(50)
);


--
-- Name: order_timeline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_timeline (
    id character varying(255) NOT NULL,
    order_id character varying(255),
    status character varying(255) NOT NULL,
    remarks text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    hub_city character varying(255),
    awb_number character varying(255)
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id character varying(255) NOT NULL,
    order_number character varying(255) NOT NULL,
    user_id character varying(255),
    address_id character varying(255),
    subtotal numeric NOT NULL,
    discount numeric DEFAULT 0,
    shipping_charge numeric DEFAULT 0,
    tax numeric DEFAULT 0,
    total_amount numeric NOT NULL,
    payment_method character varying(50) DEFAULT 'Razorpay'::character varying,
    payment_status character varying(50) DEFAULT 'Pending'::character varying,
    order_status character varying(50) DEFAULT 'Confirmed'::character varying,
    razorpay_order_id character varying(255),
    razorpay_payment_id character varying(255),
    razorpay_signature character varying(255),
    shipment_id character varying(255),
    awb_number character varying(255),
    courier_name character varying(255) DEFAULT 'ST Courier Express'::character varying,
    tracking_url text,
    estimated_delivery character varying(100),
    shipping_address text,
    packed_at timestamp without time zone,
    shipped_at timestamp without time zone,
    delivered_at timestamp without time zone,
    ordered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    coupon_code character varying(50),
    coupon_id character varying(255),
    idempotency_key character varying(80),
    razorpay_refund_id character varying(255),
    invoice_number character varying(50),
    courier_status character varying(100),
    order_source character varying(50) DEFAULT 'website'::character varying
);


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    phone character varying(50) NOT NULL,
    code character varying(10) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id character varying(255) NOT NULL,
    order_id character varying(255),
    payment_gateway character varying(50) DEFAULT 'Razorpay'::character varying,
    payment_id character varying(255),
    transaction_id character varying(255),
    amount numeric NOT NULL,
    currency character varying(10) DEFAULT 'INR'::character varying,
    status character varying(50) DEFAULT 'SUCCESS'::character varying,
    paid_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: rate_limits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_limits (
    key text NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    reset_at timestamp with time zone NOT NULL
);


--
-- Name: refunds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refunds (
    id character varying(255) NOT NULL,
    order_id character varying(255),
    razorpay_refund_id character varying(255),
    razorpay_payment_id character varying(255),
    amount numeric NOT NULL,
    status character varying(50) DEFAULT 'PROCESSED'::character varying,
    reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: review_votes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_votes (
    id integer NOT NULL,
    review_id integer NOT NULL,
    voter_ip character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: review_votes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_votes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_votes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_votes_id_seq OWNED BY public.review_votes.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id character varying(255) NOT NULL,
    user_name character varying(255),
    user_id character varying(255),
    book_id character varying(255),
    rating numeric DEFAULT 5.0,
    review text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    order_id character varying(255),
    images jsonb DEFAULT '[]'::jsonb,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    verified_purchase boolean DEFAULT true,
    helpful_count integer DEFAULT 0,
    district character varying(100),
    student_class character varying(50),
    reviewer_type character varying(50)
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id character varying(50) DEFAULT 'main'::character varying NOT NULL,
    site_name character varying(255) DEFAULT 'BLESSING POWER GUIDE'::character varying,
    support_email character varying(255) DEFAULT 'blessingpowerguide@gmail.com'::character varying,
    support_phone character varying(255) DEFAULT '+91 98404 18228'::character varying,
    razorpay_key character varying(255),
    shipping_charge numeric DEFAULT 0,
    tax_percentage numeric DEFAULT 0,
    admin_alert_phones text DEFAULT ''::text,
    checkout_paused boolean DEFAULT true,
    checkout_pause_message text DEFAULT 'Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).'::text,
    checkout_paused_at timestamp without time zone DEFAULT now(),
    checkout_paused_by character varying(255) DEFAULT 'Admin'::character varying
);


--
-- Name: stock_holds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_holds (
    id character varying(255) NOT NULL,
    hold_group_id character varying(255) NOT NULL,
    razorpay_order_id character varying(255),
    book_id character varying(255) NOT NULL,
    user_id character varying(255),
    qty integer NOT NULL,
    status character varying(20) DEFAULT 'held'::character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    released_at timestamp without time zone,
    release_reason character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    medium character varying(50)
);


--
-- Name: support_conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_conversations (
    id character varying(255) NOT NULL,
    customer_id character varying(255),
    session_token character varying(255) NOT NULL,
    customer_name character varying(255),
    customer_phone character varying(50),
    order_id character varying(255),
    status character varying(50) DEFAULT 'BOT'::character varying NOT NULL,
    assigned_admin_id character varying(255),
    assigned_admin_name character varying(255),
    accepted_at timestamp without time zone,
    resolved_at timestamp without time zone,
    last_message_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_admin_activity_at timestamp without time zone
);


--
-- Name: support_feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_feedback (
    id character varying(255) NOT NULL,
    conversation_id character varying(255) NOT NULL,
    customer_name character varying(255),
    admin_id character varying(255),
    admin_name character varying(255),
    rating integer NOT NULL,
    tags text,
    comment text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT support_feedback_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id character varying(255) NOT NULL,
    conversation_id character varying(255) NOT NULL,
    sender_type character varying(50) NOT NULL,
    sender_name character varying(255) NOT NULL,
    sender_id character varying(255),
    text text NOT NULL,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb,
    client_message_id character varying(255)
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    google_id character varying(255),
    profile_image text,
    role character varying(50) DEFAULT 'customer'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    security_question character varying(100),
    security_answer_hash character varying(255),
    profile_completed boolean DEFAULT false
);


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_events (
    id character varying(255) NOT NULL,
    event_id character varying(255) NOT NULL,
    event_type character varying(255) NOT NULL,
    payload jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: whatsapp_processed_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_processed_events (
    event_id character varying(255) NOT NULL,
    event_type character varying(50),
    processed_at timestamp with time zone DEFAULT now()
);


--
-- Name: whatsapp_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.whatsapp_sessions (
    phone character varying(30) NOT NULL,
    name character varying(255),
    step character varying(50) DEFAULT 'IDLE'::character varying,
    cart jsonb DEFAULT '[]'::jsonb,
    shipping_address jsonb,
    razorpay_order_id character varying(255),
    razorpay_payment_link_id character varying(255),
    razorpay_payment_link_url text,
    last_interaction timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    email character varying(255)
);


--
-- Name: wishlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wishlist (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    book_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: contact_submissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_submissions ALTER COLUMN id SET DEFAULT nextval('public.contact_submissions_id_seq'::regclass);


--
-- Name: review_votes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_votes ALTER COLUMN id SET DEFAULT nextval('public.review_votes_id_seq'::regclass);


--
-- Data for Name: abandoned_carts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.abandoned_carts (id, user_id, phone, name, cart_json, reminded, created_at, updated_at) FROM stdin;
ac-9842348340	usr-g-1786000184052	9842348340	Yogesh	[{"id":"bpg-1790146297047","title":"10TH STD 5 IN 1 GUIDE COMBO","qty":1,"price":1}]	f	2026-09-24 06:04:39.647708+00	2026-10-02 10:20:53.535318+00
ac-8148814326	usr-g-1788536083512	8148814326	Jeeva Blessing Tuition centre	[{"id":"bpg-1790146297047","title":"10TH STD 5 IN 1 GUIDE COMBO","qty":1,"price":1,"mrp":1650,"snapshotPrice":1300,"inStock":true}]	f	2026-09-24 19:17:58.584358+00	2026-10-01 03:22:26.08944+00
\.


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.addresses (id, user_id, full_name, phone, alternate_phone, address_line1, address_line2, city, district, state, country, pincode, landmark, is_default, created_at, near_landmark) FROM stdin;
addr-1786409756997-7hel	usr-g-1786409721513	Yogesh T	8248345770	\N	Gn Chetty Street Arani	\N	Tiruvallur	\N	Tamil Nadu	India	601101	HOME	t	2026-08-11 00:55:56.997213	\N
addr-1788591680924-xguw	usr_1788591637292_9o0z0	bhavani	8680984881	\N	No:41A Kamarajar Street,	\N	Chennai	\N	Tamil Nadu	India	600023	HOME	t	2026-09-05 07:01:20.925188	\N
addr-1785763850491-qpau	usr_1785762703802_xr7yc	yogesh	9360345770	9360345771	NO 816 GN CHETTY ST	\N	ARANI	\N	Tamil Nadu	India	601101	HOME	t	2026-08-03 13:30:50.491622	\N
addr-1789865997638-hazn	usr_1785762703802_xr7yc	Yogesh T	8248345770	9894490969	NO 816 GN CHETTY ST	\N	ARANI	\N	Tamil Nadu	India	601101	HOME	f	2026-09-20 00:59:57.638929	near jpb hotel
addr-1786002475254-vadf	usr-g-1786000184052	Yogesh T	9842348340	8248345770	2, Sakthivel Nagar Street	\N	Chennai	\N	Tamil Nadu	India	600066	HOME	t	2026-08-06 07:47:55.255038	\N
addr-1790214863225-vpfr	usr-g-1785540503002	Yogesh T	8248345770	9600219439	Gn Chetty Street Arani	\N	Tiruvallur	\N	Tamil Nadu	India	601101	HOME	t	2026-09-24 01:54:23.225522	\N
addr-1785834299376-77mt	usr-g-1785834276184	YOGESH T	8248345779	9721872333	d1ddeq	\N	wqwddwq	\N	Tamil Nadu	India	625001	HOME	t	2026-08-04 09:04:59.376506	\N
addr-1790257243202-89hs	usr-g-1790257137701	Jo Princy	8098016112	9092052614	no:13, karumarriamman Kovil Street, thuvakudi malai, trichy	\N	trichy	\N	Tamil Nadu	India	620022	HOME	t	2026-09-24 13:40:43.202673	Emanuel church
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, target_type, target_id, details, created_at, ip_address, user_agent) FROM stdin;
audit-1790605870195-5mnz6xs	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 68, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 43, "stock_english": 25, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 14:31:10.198991	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790610771924-s07yupb	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 43, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 43, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 15:52:51.934064	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614131351-dr8dm7r	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 0, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "out_of_stock", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:48:51.354854	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790650980843-jvfd	admin	ORDER_CANCELLED	order	ord-1790607476735-MAMACK	{"amount": 1, "reason": "Cancelled prior to ST Courier dispatch", "isReturn": false, "refundId": null, "refunded": false, "orderNumber": "BPG-WA-MAMACK"}	2026-09-29 03:03:00.843966	\N	\N
audit-1790651216259-4ruz	system	ORDER_CANCELLED	order	ord-1790607013291	{"amount": 1, "reason": "Reconciled via Razorpay webhook: refund.created (ID: rfnd_ThhLSkeCtDrwSL)", "isReturn": false, "refundId": "rfnd_ThhLSkeCtDrwSL", "refunded": true, "orderNumber": "BPG-D6LYJFA3"}	2026-09-29 03:06:56.259518	\N	\N
audit-1790824946030-gkgn6rj	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-01 03:22:26.038928	2401:4900:9261:e10c:c07e:3dff:fe8d:f5bf	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790930868970-0ul22t5	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-10th-english	{"deletedId": "bpg-10th-english"}	2026-10-02 08:47:48.975755	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790930890157-wmvw3l9	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 58, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 08:48:10.160974	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790936175879-il6ahu6	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-10-02 10:16:15.88438	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1789891202226-bn4kapp	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1786767984265	{"badge": "", "price": 350, "stock": 24, "title": "10TH TAMIL GUIDE", "status": "published", "subject": "General", "category_id": "cat-10th", "cover_image": "https://res.cloudinary.com/wpkjkqoh/image/upload/v1786767976/blessing_power_guides/g8yvldnfdceqk2eg3p0r.jpg", "discount_price": 20, "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}	2026-09-20 08:00:02.241733	2401:4900:cccb:cc86:500f:26dd:c8a9:3c80	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1789917229950-o2erkqk	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1786767984265	{"status": "out_of_stock"}	2026-09-20 15:13:50.00859	2401:4900:cced:8f8c:f915:83b1:d8b4:30f8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1789917235873-za5fe1h	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1786767984265	{"status": "published"}	2026-09-20 15:13:55.877165	2401:4900:cced:8f8c:f915:83b1:d8b4:30f8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1789917242287-145g6fy	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1786767984265	{"status": "out_of_stock"}	2026-09-20 15:14:02.30631	2401:4900:cced:8f8c:f915:83b1:d8b4:30f8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1789917250069-2h06r27	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1786767984265	{"status": "published"}	2026-09-20 15:14:10.072038	2401:4900:cced:8f8c:f915:83b1:d8b4:30f8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790606380100-21u9jxl	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 44, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 44, "stock_english": 0, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 14:39:40.133747	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790146297094-c3qjgq0	usr-g-1785540503002	PRODUCT_CREATED	book	bpg-1790146297047	{"price": 1650, "stock": 50, "title": "10TH STD 5 IN 1 GUIDE COMBO", "discount_price": 1300}	2026-09-23 06:51:37.100123	2401:4900:634f:1747:cc39:9dff:fef6:35b4	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790610887998-43g95v8	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 43, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 43, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-28 15:54:48.00309	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614135988-ejw9z2t	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 0, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-28 16:48:55.994826	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790651250041-4yzs	admin	ORDER_CANCELLED	order	ord-1790490477223	{"amount": 1, "reason": "Cancelled prior to ST Courier dispatch", "isReturn": false, "refundId": null, "refunded": false, "orderNumber": "BPG-FSU5JBAP"}	2026-09-29 03:07:30.041539	\N	\N
audit-1790229639472-5fh9a9x	usr-g-1785540503002	USER_DELETED	user	usr_syn_1790164896880	{"deletedUserId": "usr_syn_1790164896880"}	2026-09-24 06:00:39.474453	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229642985-cy4f7lq	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790217474312	{"deletedUserId": "usr_coupon_combo_1790217474312"}	2026-09-24 06:00:42.98699	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229644759-1bbvh25	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790217396936	{"deletedUserId": "usr_coupon_combo_1790217396936"}	2026-09-24 06:00:44.760829	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229647561-e0czc1f	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790217126013	{"deletedUserId": "usr_coupon_combo_1790217126013"}	2026-09-24 06:00:47.563338	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229651832-s0uuseq	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790216072008	{"deletedUserId": "usr_coupon_combo_1790216072008"}	2026-09-24 06:00:51.834026	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229654523-jio4gmh	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790216041136	{"deletedUserId": "usr_coupon_combo_1790216041136"}	2026-09-24 06:00:54.524499	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229664430-jwv7eng	usr-g-1785540503002	USER_DELETED	user	usr_coupon_combo_1790216018622	{"deletedUserId": "usr_coupon_combo_1790216018622"}	2026-09-24 06:01:04.432061	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790229667323-75bahso	usr-g-1785540503002	USER_DELETED	user	usr_syn_1790164992424	{"deletedUserId": "usr_syn_1790164992424"}	2026-09-24 06:01:07.325062	2401:4900:67c4:6da8:64ed:181d:8ee6:997b	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790304245565-02ijrhr	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil / English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "sample_pdf_url": null}	2026-09-25 02:44:05.570101	2401:4900:ccd4:c489:c177:6cfc:6ebc:285a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790304253241-zm7ofy5	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "sample_pdf_url": null}	2026-09-25 02:44:13.245316	2401:4900:ccd4:c489:c177:6cfc:6ebc:285a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790304260351-v1em64n	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1786767984265	{"badge": "", "price": 350, "stock": 24, "title": "10TH TAMIL GUIDE", "status": "published", "subject": "General", "language": "Tamil", "category_id": "cat-combos", "cover_image": "https://res.cloudinary.com/wpkjkqoh/image/upload/v1786767976/blessing_power_guides/g8yvldnfdceqk2eg3p0r.jpg", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 20, "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}	2026-09-25 02:44:20.354199	2401:4900:ccd4:c489:c177:6cfc:6ebc:285a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790313293449-gopfe11	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"Chemistry\\"]", "discount_price": 1300, "sample_pdf_url": null}	2026-09-25 05:14:53.452383	2409:40f4:1019:8145:1134:386a:f129:8b6c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790313313547-aeq6to9	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "sample_pdf_url": null}	2026-09-25 05:15:13.553656	2409:40f4:1019:8145:1134:386a:f129:8b6c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790313314106-ge9jmin	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "sample_pdf_url": null}	2026-09-25 05:15:14.109531	2409:40f4:1019:8145:1134:386a:f129:8b6c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-chk-1790336712774-7zgj	usr-g-1785540503002	CHECKOUT_ACTIVATED	system_settings	checkout_control	{"paused": false, "message": "Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).", "timestamp": "2026-09-25T11:45:12.773Z"}	2026-09-25 11:45:12.774352	\N	\N
audit-1790336810953-9zjtcdt	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-1786767984265	{"deletedId": "bpg-1786767984265"}	2026-09-25 11:46:50.957813	2401:4900:93f9:1570:2c55:8c30:fc09:e8dc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790336858558-did442v	usr-g-1785540503002	PRODUCT_CREATED	book	bpg-1790336858543	{"price": 350, "stock": 50, "title": "10th Standard Tamil Book", "discount_price": 0.2}	2026-09-25 11:47:38.561248	2401:4900:93f9:1570:2c55:8c30:fc09:e8dc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790338046757-3kf4y4l	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "Popular", "price": 350, "stock": 50, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": null, "sample_pdf_url": null}	2026-09-25 12:07:26.762606	2401:4900:93f9:1570:2c55:8c30:fc09:e8dc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790338083860-28fz2fj	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "Popular", "price": 350, "stock": 50, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "combo_subjects": "[\\"Tamil\\"]", "discount_price": null, "sample_pdf_url": null}	2026-09-25 12:08:03.867588	2401:4900:93f9:1570:2c55:8c30:fc09:e8dc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-chk-1790342333660-i54i	usr-g-1785540503002	CHECKOUT_PAUSED	system_settings	checkout_control	{"paused": true, "message": "Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).", "timestamp": "2026-09-25T13:18:53.659Z"}	2026-09-25 13:18:53.660461	\N	\N
audit-chk-1790395860073-3d5r	usr-g-1785540503002	CHECKOUT_ACTIVATED	system_settings	checkout_control	{"paused": false, "message": "Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).", "timestamp": "2026-09-26T04:11:00.072Z"}	2026-09-26 04:11:00.073846	\N	\N
audit-1790396032247-3z0xwyw	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1790336858543	{"status": "out_of_stock", "combo_subjects": "[]"}	2026-09-26 04:13:52.251725	2401:4900:ca8a:5e4e:8c8a:6dff:febf:da1f	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790396036639-qatvcie	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1790336858543	{"status": "published", "combo_subjects": "[]"}	2026-09-26 04:13:56.642743	2401:4900:ca8a:5e4e:8c8a:6dff:febf:da1f	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790396040961-d3djaxs	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1790146297047	{"status": "out_of_stock"}	2026-09-26 04:14:00.963875	2401:4900:ca8a:5e4e:8c8a:6dff:febf:da1f	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790396042569-jtn01w8	usr-g-1785540503002	PRODUCT_UPDATED	book	bpg-1790146297047	{"status": "published"}	2026-09-26 04:14:02.582926	2401:4900:ca8a:5e4e:8c8a:6dff:febf:da1f	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790396375645-3hfw9nz	usr-g-1785540503002	PRODUCT_CREATED	book	bpg-1790396375629	{"price": 350, "stock": 50, "title": "8th Standard All-in-One Complete Guide Combo Pack (5 Books)", "discount_price": 10}	2026-09-26 04:19:35.647911	2401:4900:ca8a:5e4e:8c8a:6dff:febf:da1f	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-chk-1790396390999-32cy	usr-g-1785540503002	CHECKOUT_PAUSED	system_settings	checkout_control	{"paused": true, "message": "Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).", "timestamp": "2026-09-26T04:19:50.999Z"}	2026-09-26 04:19:50.999765	\N	\N
audit-1790487766526-m3l28ih	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-1790396375629	{"deletedId": "bpg-1790396375629"}	2026-09-27 05:42:46.529234	2401:4900:cab8:eb1a:10be:29a4:ae0b:a7c5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790488102764-5mc118q	usr-g-1785540503002	USER_DELETED	user	usr-g-1790395716391	{"deletedUserId": "usr-g-1790395716391"}	2026-09-27 05:48:22.764915	2401:4900:cab8:eb1a:10be:29a4:ae0b:a7c5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790606488510-39zgp8n	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 44, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 44, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 14:41:28.54191	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790612255701-dc81jvq	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 43, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 43, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:17:35.76297	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-chk-1790490106890-f97r	usr-g-1785540503002	CHECKOUT_ACTIVATED	system_settings	checkout_control	{"paused": false, "message": "Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).", "timestamp": "2026-09-27T06:21:46.889Z"}	2026-09-27 06:21:46.890472	\N	\N
audit-1790614267727-kvhwq3c	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 23, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-28 16:51:07.72981	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790664871616-cfc9md8	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-29 06:54:31.620796	2401:4900:4dfa:a68a:68cd:8cff:fef4:f61d	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790825021450-axzb	admin	ORDER_CANCELLED	order	ord-1790824972060	{"amount": 1, "reason": "Cancelled prior to ST Courier dispatch", "isReturn": false, "refundId": "rfnd_TiUhyTBY4mmK6x", "refunded": true, "orderNumber": "BPG-YY80SOVG"}	2026-10-01 03:23:41.450351	\N	\N
audit-1790930869827-tfg7hxi	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-10th-maths	{"deletedId": "bpg-10th-maths"}	2026-10-02 08:47:49.829976	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790490174843-ix98zfk	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-27 06:22:54.852597	2401:4900:cab8:eb1a:10be:29a4:ae0b:a7c5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790490182770-qwkfz4h	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "Popular", "price": 350, "stock": 50, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "combo_subjects": "[]", "discount_price": 0.2, "sample_pdf_url": null}	2026-09-27 06:23:02.783244	2401:4900:cab8:eb1a:10be:29a4:ae0b:a7c5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790491586120-3qrfbw7	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-27 06:46:26.126355	223.237.184.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790491799186-8e61k0e	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-27 06:49:59.210621	223.237.184.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790491818277-mkkwawc	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Bilingual", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-27 06:50:18.280196	223.237.184.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790491853209-u7741qr	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-27 06:50:53.213268	223.237.184.166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790564398297-fb93cnj	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Popular", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 02:59:58.304719	2401:4900:7b9b:644c:dcdf:93c0:3af1:e4f9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790566117564-tajw05z	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 45, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "combo_subjects": "[]", "discount_price": 0.2, "sample_pdf_url": null}	2026-09-28 03:28:37.568881	2401:4900:7b9b:644c:dcdf:93c0:3af1:e4f9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790566132740-ewrrn0h	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 49, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 03:28:52.744749	2401:4900:7b9b:644c:dcdf:93c0:3af1:e4f9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790581453844-fgvbct8	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 25, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": 25, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 07:44:13.848292	2409:40f4:101c:9f9a:598d:6971:7e45:9546	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790581478283-5ikhq5j	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 37, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 12, "stock_english": 25, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 07:44:38.287159	2409:40f4:101c:9f9a:598d:6971:7e45:9546	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790606523449-3lrs4cx	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-1790336858543	{"deletedId": "bpg-1790336858543"}	2026-09-28 14:42:03.454781	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790612919018-vodl3f6	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 0, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "out_of_stock", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:28:39.023932	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614287550-hpdmsaw	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 23, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:51:27.552694	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790665701072-ytspmn2	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-29 07:08:21.075135	2401:4900:4dfa:a68a:68cd:8cff:fef4:f61d	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790825093050-s9et6gl	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-10-01 03:24:53.0555	2401:4900:9261:e10c:c07e:3dff:fe8d:f5bf	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790930870725-bopyvtc	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-10th-tamil	{"deletedId": "bpg-10th-tamil"}	2026-10-02 08:47:50.727746	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790589017760-4fwk0oy	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 259, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 234, "stock_english": 25, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 09:50:17.767114	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790606668207-art18do	usr-g-1785540503002	PRODUCT_CREATED	book	bpg-1790606668190	{"price": 350, "stock": 50, "title": "12 th french", "discount_price": 280}	2026-09-28 14:44:28.208969	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614107887-vmrkbao	usr-g-1785540503002	STOCK_CHANGED	book	bpg-1790146297047	{"stock": 10, "status": "published", "stock_tamil": 10, "stock_english": null}	2026-09-28 16:48:27.890345	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614295645-tf94eir	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 0, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "out_of_stock", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:51:35.648591	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790589837023-69h21ig	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 45, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": null, "stock_english": null, "combo_subjects": "[]", "discount_price": 21, "sample_pdf_url": null}	2026-09-28 10:03:57.034992	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790690648723-il2s2hl	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-29 14:04:08.729982	2401:4900:6331:5655:8075:e2e7:ec6d:d76	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790919618287-7mu46mb	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-10-02 05:40:18.292667	2401:4900:caa2:aff2:1c61:d47a:62c9:4714	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790930871860-oemufcv	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-10th-science	{"deletedId": "bpg-10th-science"}	2026-10-02 08:47:51.863819	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790936171662-t5lv9jr	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 10:16:11.666955	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790936247068-blrg13q	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 10:17:27.071434	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790940922686-wxz0ytq	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-10-02 11:35:22.690798	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790940943442-wu5vueg	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 0, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "out_of_stock", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 0, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 11:35:43.48627	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790590264194-b5fgzwv	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 25, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Both", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 0, "stock_english": 25, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "sample_pdf_url": null}	2026-09-28 10:11:04.199768	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790606713427-i3808ab	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-1790606668190	{"deletedId": "bpg-1790606668190"}	2026-09-28 14:45:13.430298	2401:4900:9156:fd3b:44ae:e872:af17:124a	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614111818-r8qa4n0	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:48:31.822583	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614380767-cs7o37p	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 34, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 34, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-09-28 16:53:00.797596	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790614387740-yn6zcuj	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 34, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 34, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-28 16:53:07.743745	2401:4900:9156:fd3b:25d9:c5bb:662a:18bf	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790591880838-g6yzkth	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 68, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Both", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": 45, "stock_english": 23, "combo_subjects": "[]", "discount_price": 21, "sample_pdf_url": null}	2026-09-28 10:38:00.842879	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790591919272-g7s8hwq	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 45, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": 45, "stock_english": null, "combo_subjects": "[]", "discount_price": 21, "sample_pdf_url": null}	2026-09-28 10:38:39.277428	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790591932779-es9pu6w	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 45, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Tamil", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": 45, "stock_english": null, "combo_subjects": "[]", "discount_price": 0.2, "sample_pdf_url": null}	2026-09-28 10:38:52.810602	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790593679043-68qz2ue	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 45, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Both", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": 45, "stock_english": 0, "combo_subjects": "[]", "discount_price": 0.2, "sample_pdf_url": null}	2026-09-28 11:07:59.048279	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790593681847-lmg9gtk	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790336858543	{"badge": "", "price": 350, "stock": 47, "title": "10th Standard Tamil Book", "status": "published", "subject": "Tamil", "language": "Both", "category_id": "cat-10th", "cover_image": "/uploads/catalog/img-1790336857371-gmn059.jpg", "stock_tamil": 45, "stock_english": 2, "combo_subjects": "[]", "discount_price": 0.2, "sample_pdf_url": null}	2026-09-28 11:08:01.868756	2401:4900:9156:fd3b:b959:3d35:9b07:4091	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
audit-1790739319971-npp3k33	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\"]", "discount_price": 1300, "is_coming_soon": true, "sample_pdf_url": null}	2026-09-30 03:35:19.974421	2401:4900:9153:34db:483d:dbff:fef9:9f14	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36
audit-1790929730265-jfnbrn4	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 35, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "Tamil", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": 35, "stock_english": null, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 08:28:50.273053	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790930872694-aeav34b	usr-g-1785540503002	PRODUCT_DELETED	book	bpg-10th-social	{"deletedId": "bpg-10th-social"}	2026-10-02 08:47:52.696387	2401:4900:93ee:2abf:2c79:bf86:c36:ded2	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790940955960-umjy0r1	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "published", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": false, "sample_pdf_url": null}	2026-10-02 11:35:55.962605	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
audit-1790940977414-j804nyw	usr-g-1785540503002	PRICE_CHANGED	book	bpg-1790146297047	{"badge": "Combo Set", "price": 1650, "stock": 23, "title": "10TH STD 5 IN 1 GUIDE COMBO", "status": "coming_soon", "subject": "All-in-One Full Set (Combo)", "language": "English", "category_id": "cat-combos", "cover_image": "/uploads/catalog/img-1790146292664-eqgiz5.png", "stock_tamil": null, "stock_english": 23, "combo_subjects": "[\\"Tamil\\",\\"English\\",\\"Mathematics\\",\\"Science\\",\\"Social Science\\",\\"FRENCH\\"]", "discount_price": 1, "is_coming_soon": true, "sample_pdf_url": null}	2026-10-02 11:36:17.416915	2401:4900:93ee:2abf:8498:5986:8e33:62a4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
\.


--
-- Data for Name: book_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.book_images (id, book_id, image_url, display_order) FROM stdin;
\.


--
-- Data for Name: books; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.books (id, title, slug, isbn, author, publisher, edition, language, semester, department, subject, category_id, description, price, discount_price, stock, pages, weight, cover_image, status, featured, created_at, updated_at, badge, sample_pdf_url, combo_subjects, stock_tamil, stock_english, is_coming_soon) FROM stdin;
bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO	10th-std-5-in-1-guide-combo-297047	\N	Blessing Editorial Board	Blessing Pathway Education	2026 Edition	English	\N	\N	All-in-One Full Set (Combo)	cat-combos	Complete 10th Standard All-in-One Full Set (Combo) guide covering Tamil Nadu Samacheer Kalvi syllabus with question banks and answers.	1650	1	23	240	400g	/uploads/catalog/img-1790146292664-eqgiz5.png	coming_soon	t	2026-09-23 06:51:37.059099	2026-10-02 11:36:17.404256	Combo Set	\N	["Tamil", "English", "Mathematics", "Science", "Social Science", "FRENCH"]	\N	23	t
\.


--
-- Data for Name: cart; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart (id, user_id, created_at) FROM stdin;
cart-usr-g-1785540503002	usr-g-1785540503002	2026-07-31 23:28:23.05138
cart-usr_1785762703802_xr7yc	usr_1785762703802_xr7yc	2026-08-03 13:11:44.477803
cart-usr-g-1785834276184	usr-g-1785834276184	2026-08-04 09:04:36.268375
cart-usr-g-1786000184052	usr-g-1786000184052	2026-08-06 07:09:44.135126
cart-admin-bpg-001	admin-bpg-001	2026-08-08 06:09:59.134828
cart-usr-g-1786409721513	usr-g-1786409721513	2026-08-11 00:55:21.569913
cart-usr-g-1788536083512	usr-g-1788536083512	2026-09-04 15:34:43.595939
cart-usr-g-1788536325567	usr-g-1788536325567	2026-09-04 15:38:45.62294
cart-usr_1788591637292_9o0z0	usr_1788591637292_9o0z0	2026-09-05 07:00:38.030228
cart-usr-g-1790042184874	usr-g-1790042184874	2026-09-22 01:56:24.932338
cart-usr-g-1790257137701	usr-g-1790257137701	2026-09-24 13:38:57.758375
\.


--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cart_items (id, cart_id, book_id, quantity, price) FROM stdin;
ci-1790443377967-443	cart-usr-g-1788536083512	bpg-1790146297047	1	1300
ci-1790936453535-673	cart-usr-g-1786000184052	bpg-1790146297047	1	1
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, slug, image, parent_category, status) FROM stdin;
cat-9th	9th Standard Guides	9th	\N	\N	active
cat-7th	7th Standard Guides	7th	\N	\N	active
cat-combos	Combo Packs	combos	\N	\N	active
cat-8th	8th Standard Guides	8th	\N	\N	active
cat-10th	10th Standard Guides	10th	\N	\N	active
cat-12th	12th Standard Guides	12th	\N	\N	active
cat-6th	6th Standard Guides	6th	\N	\N	active
cat-11th	11th Standard Guides	11th	\N	\N	active
\.


--
-- Data for Name: checkout_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checkout_sessions (id, user_id, razorpay_order_id, hold_group_id, status, cart_snapshot, price_snapshot, shipping_address, subtotal, discount, shipping_fee, total_amount, coupon_code, coupon_id, order_id, created_at, updated_at, source) FROM stdin;
cs-1790313906879-8r0rz	usr-g-1785540503002	order_Tg9ZWlpZzfKwA4	hold-1790313906624-9ghk09	EXPIRED	[{"id": "bpg-1786767984265", "qty": 1, "price": 20, "title": "10TH TAMIL GUIDE", "subtotal": 20}, {"id": "bpg-1790146297047", "qty": 1, "price": 1300, "title": "10TH STD 5 IN 1 GUIDE COMBO", "subtotal": 1300}]	{"subtotal": 1320, "shippingFee": 0, "totalAmount": 1320, "discountAmount": 0}	{"id": "addr-1790214863225-vpfr", "city": "Tiruvallur", "name": "Yogesh T", "type": "HOME", "phone": "8248345770", "state": "Tamil Nadu", "address": "Gn Chetty Street Arani", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9600219439"}	1320	0	0	1320	\N	\N	\N	2026-09-25 05:25:06.87999+00	2026-09-25 05:39:41.011149+00	website
cs-1790313598392-jmjrt	usr-g-1785540503002	order_Tg9U62E4hzcJj5	hold-1790313598068-klqslv	EXPIRED	[{"id": "bpg-1786767984265", "qty": 5, "price": 20, "title": "10TH TAMIL GUIDE", "subtotal": 100}]	{"subtotal": 100, "shippingFee": 0, "totalAmount": 100, "discountAmount": 0}	{"id": "addr-1790214863225-vpfr", "city": "Tiruvallur", "name": "Yogesh T", "type": "HOME", "phone": "8248345770", "state": "Tamil Nadu", "address": "Gn Chetty Street Arani", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9600219439"}	100	0	0	100	\N	\N	\N	2026-09-25 05:19:58.392697+00	2026-09-25 05:48:56.555476+00	website
cs-1790336769391-nzn4b	usr_1785762703802_xr7yc	order_TgG42DDMIcxOeI	hold-1790336768962-gu0y1r	EXPIRED	[{"id": "bpg-1786767984265", "qty": 1, "price": 20, "title": "10TH TAMIL GUIDE", "medium": "Tamil Medium", "subtotal": 20, "selectedMedium": "Tamil Medium"}]	{"subtotal": 20, "shippingFee": 0, "totalAmount": 20, "discountAmount": 0}	{"id": "addr-1785763850491-qpau", "city": "ARANI", "name": "yogesh", "type": "HOME", "phone": "9360345770", "state": "Tamil Nadu", "address": "NO 816 GN CHETTY ST", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9360345771"}	20	0	0	20	\N	\N	\N	2026-09-25 11:46:09.391757+00	2026-09-25 12:10:22.424201+00	website
cs-1790490457025-qups1	usr_1785762703802_xr7yc	order_Tgxhn9hBAPvmPg	hold-1790490456747-ye6b0q	ORDER_CONFIRMED	[{"id": "bpg-1790336858543", "qty": 5, "price": 0.2, "title": "10th Standard Tamil Book", "medium": null, "subtotal": 1, "selectedMedium": null}]	{"subtotal": 1, "shippingFee": 0, "totalAmount": 1, "discountAmount": 0}	{"id": "addr-1785763850491-qpau", "city": "ARANI", "name": "yogesh", "type": "HOME", "phone": "9360345770", "state": "Tamil Nadu", "address": "NO 816 GN CHETTY ST", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9360345771"}	1	0	0	1	\N	\N	ord-1790490477223	2026-09-27 06:27:37.026621+00	2026-09-27 06:27:57.222233+00	website
cs-1790606974715-a01e7	usr_1785762703802_xr7yc	order_ThUn9QT2rQosrO	hold-1790606974412-bqx5eb	ORDER_CONFIRMED	[{"id": "bpg-1790146297047", "qty": 1, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Tamil Medium", "subtotal": 1, "selectedMedium": "Tamil Medium"}]	{"subtotal": 1, "shippingFee": 0, "totalAmount": 1, "discountAmount": 0}	{"id": "addr-1785763850491-qpau", "city": "ARANI", "name": "yogesh", "type": "HOME", "phone": "9360345770", "state": "Tamil Nadu", "address": "NO 816 GN CHETTY ST", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9360345771"}	1	0	0	1	\N	\N	ord-1790607013291	2026-09-28 14:49:34.715646+00	2026-09-28 14:50:13.289503+00	website
cs-1790664889120-miqv5	usr-g-1785834276184	order_ThlElabiqDa3aA	hold-1790664888786-s4leo2	EXPIRED	[{"id": "bpg-1790146297047", "qty": 1, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Tamil Medium", "subtotal": 1, "selectedMedium": "Tamil Medium"}]	{"subtotal": 1, "shippingFee": 0, "totalAmount": 1, "discountAmount": 0}	{"id": "addr-1785834299376-77mt", "city": "wqwddwq", "name": "YOGESH T", "type": "HOME", "phone": "8248345779", "state": "Tamil Nadu", "address": "d1ddeq", "pincode": "625001", "landmark": "", "isDefault": true, "alternatePhone": "9721872333"}	1	0	0	1	\N	\N	\N	2026-09-29 06:54:49.121257+00	2026-09-29 07:15:40.558148+00	website
cs-1790824956385-1h47y	usr-g-1785540503002	order_TiUgqAk37ulhyj	hold-1790824956027-5ao18x	ORDER_CONFIRMED	[{"id": "bpg-1790146297047", "qty": 1, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Tamil Medium", "subtotal": 1, "selectedMedium": "Tamil Medium"}]	{"subtotal": 1, "shippingFee": 0, "totalAmount": 1, "discountAmount": 0}	{"id": "addr-1790214863225-vpfr", "city": "Tiruvallur", "name": "Yogesh T", "type": "HOME", "phone": "8248345770", "state": "Tamil Nadu", "address": "Gn Chetty Street Arani", "pincode": "601101", "landmark": "", "isDefault": true, "alternatePhone": "9600219439"}	1	0	0	1	\N	\N	ord-1790824972060	2026-10-01 03:22:36.385771+00	2026-10-01 03:22:52.05878+00	website
chk-wa-1790931342444	wa-8248345770	plink_TiytpHHcsO8WHa	\N	PAYMENT_PENDING	[{"id": "bpg-1790146297047", "qty": 2, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Combo", "isCombo": true}]	{"total": 2, "shipping": 0, "subtotal": 2}	{"city": "Tamil Nadu", "name": "YOGESH 👊", "address": "Hii", "pincode": "600001"}	2	0	0	2	\N	\N	\N	2026-10-02 08:55:42.444977+00	2026-10-02 08:55:42.444977+00	whatsapp
chk-wa-1790931462884	wa-8248345770	order_Tiyw0nFJjtpRxp	\N	ORDER_CONFIRMED	[{"id": "bpg-1790146297047", "qty": 2, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Combo", "isCombo": true}]	{"total": 2, "shipping": 0, "subtotal": 2}	{"city": "Tamil Nadu", "name": "YOGESH 👊", "address": "No 860 gn chetty st arani,Thiruvallur-601101", "pincode": "601101"}	2	0	0	2	\N	\N	ord-1790934728637	2026-10-02 08:57:42.884925+00	2026-10-02 09:52:08.633775+00	whatsapp
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages (id, name, email, phone, message, created_at) FROM stdin;
\.


--
-- Data for Name: contact_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_submissions (id, contact_id, name, email, phone, subject, message, status, created_at) FROM stdin;
2	MSG-1789890269494	<script>alert("xss")</script>	attacker@test.com	9999999999	Inquiry <img src=x onerror=alert(1)>	Hello <iframe src="evil.com"></iframe>	unread	2026-09-20 07:44:29.495087+00
3	MSG-1789890312091	<script>alert("xss")</script>	attacker@test.com	9999999999	Inquiry <img src=x onerror=alert(1)>	Hello <iframe src="evil.com"></iframe>	unread	2026-09-20 07:45:12.092258+00
4	MSG-1789891210067	<script>alert("xss")</script>	attacker@test.com	9999999999	Inquiry <img src=x onerror=alert(1)>	Hello <iframe src="evil.com"></iframe>	unread	2026-09-20 08:00:10.067588+00
5	MSG-1789909430894	<script>alert("xss")</script>	attacker@test.com	9999999999	Inquiry <img src=x onerror=alert(1)>	Hello <iframe src="evil.com"></iframe>	unread	2026-09-20 13:03:50.894958+00
6	MSG-1789915569495	<script>alert("xss")</script>	attacker@test.com	9999999999	Inquiry <img src=x onerror=alert(1)>	Hello <iframe src="evil.com"></iframe>	unread	2026-09-20 14:46:09.495757+00
7	MSG-1789917283712	Kishore kumar	kk@gmail.com	9791952277	Guide Book Inquiry	Maths midium other subject 90/ok	unread	2026-09-20 15:14:43.712458+00
8	MSG-1790409865728	Ahilan		9500429289	ST Courier Delivery Status	Ahilan\nS/o Rajeshwaran, abiraham nagar, opp grace ministries,\nperiyanayagapuram.\nTuticorin - 628101	unread	2026-09-26 08:04:25.728986+00
\.


--
-- Data for Name: coupon_redemptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupon_redemptions (id, coupon_id, user_id, order_id, created_at) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.coupons (id, code, discount_type, discount_value, min_cart_qty, min_order_amount, max_discount_amount, max_uses, used_count, is_active, expires_at, created_at, title, show_on_hero) FROM stdin;
cpn-1789866158621-keok	BPGFIRST	flat	150.00	4	0.00	\N	100	0	t	2026-10-01 00:00:00	2026-09-20 01:02:38.622442	USE BPGFIRST AND GET 150 RS DISCOUNT	t
\.


--
-- Data for Name: courier_tracking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.courier_tracking (id, order_id, awb_number, docket_number, status, current_status, location, remarks, event_time, courier_name, origin_hub, destination_hub, estimated_delivery, scraped_events, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_otps (id, email, otp, expires_at, verified, created_at) FROM stdin;
\.


--
-- Data for Name: failed_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_webhook_events (id, event_id, event_type, payload, error_message, retry_count, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.faqs (id, question, answer, display_order, status, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_sequences (financial_year, last_number, updated_at) FROM stdin;
26-27	18	2026-10-02 09:52:08.633775
\.


--
-- Data for Name: job_heartbeats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_heartbeats (job_name, last_run_at, status, duration_ms, last_error, details, updated_at) FROM stdin;
confirmExpire	2026-10-02 13:44:38.295804+00	ok	2	\N	{"cancelledCount": 0}	2026-10-02 13:44:38.295804+00
courierSyncCron	2026-10-02 13:44:38.316647+00	ok	20	\N	{"checked": 0, "updated": 0}	2026-10-02 13:44:38.316647+00
reconcileUnfinalizedRefunds	2026-10-02 13:48:38.312978+00	ok	12	\N	{"reconciledOrders": 0, "deadLetterResolved": 0}	2026-10-02 13:48:38.312978+00
stockHoldSweep	2026-10-02 13:48:38.317618+00	ok	16	\N	{"releasedCount": 0}	2026-10-02 13:48:38.317618+00
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, title, message, type, is_read, created_at) FROM stdin;
notif-1790650980841-l5l6	wa_8248345770	Order #BPG-WA-MAMACK Cancelled	Your order #BPG-WA-MAMACK was cancelled by store admin (Cancelled prior to ST Courier dispatch).	warning	f	2026-09-29 03:03:00.841902
notif-1790651250039-s86b	usr_1785762703802_xr7yc	Order #BPG-FSU5JBAP Cancelled	Your order #BPG-FSU5JBAP was cancelled by store admin (Cancelled prior to ST Courier dispatch).	warning	t	2026-09-29 03:07:30.039396
notif-1790651216257-ncyj	usr_1785762703802_xr7yc	Order #BPG-D6LYJFA3 Cancelled & Refunded	Your order #BPG-D6LYJFA3 was cancelled. Razorpay refund of ₹1 succeeded (ID: rfnd_ThhLSkeCtDrwSL). Money usually reaches your UPI/card in 5–7 working days.	refund	t	2026-09-29 03:06:56.257995
notif-1790825021448-1aox	usr-g-1785540503002	Order #BPG-YY80SOVG Cancelled & Refunded	Your order #BPG-YY80SOVG was cancelled. Razorpay refund of ₹1 succeeded (ID: rfnd_TiUhyTBY4mmK6x). Money usually reaches your UPI/card in 5–7 working days.	refund	t	2026-10-01 03:23:41.448333
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, book_id, book_title, book_price, quantity, subtotal, medium) FROM stdin;
item-1790607013291-g7fb	ord-1790607013291	bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO (Tamil Medium)	1	1	1	Tamil Medium
item-1790607476739-uszcu	ord-1790607476735-MAMACK	bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO	1	1	1	\N
item-1790824972060-orv6	ord-1790824972060	bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO (Tamil Medium)	1	1	1	Tamil Medium
item-1790934728637-213z	ord-1790934728637	bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO (Combo)	1	2	2	Combo
item-1790257606351	ord-1790257606351	bpg-1790146297047	10TH STD 5 IN 1 GUIDE COMBO	1300	1	1300	\N
item-1790490477223-q0og	ord-1790490477223	bpg-1790336858543	10th Standard Tamil Book	0.2	5	1	\N
\.


--
-- Data for Name: order_timeline; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_timeline (id, order_id, status, remarks, created_at, hub_city, awb_number) FROM stdin;
tl-1790299145394	ord-1790257606351	Payment Confirmed	Razorpay payment confirmed via UPI (pay_TftZm1Qr3zgN62, RRN 626772017848). Order reconciled into system.	2026-09-24 13:46:46.351	\N	\N
tl-1790490477228	ord-1790490477223	Payment Confirmed	Payment verified & order finalized via webhook (ID: pay_TgxhvmwvD49sUq)	2026-09-27 06:27:57.222233	\N	\N
tl-1790607013295	ord-1790607013291	Payment Confirmed	Payment verified & order finalized via webhook (ID: pay_ThUnmxq28jNqQw)	2026-09-28 14:50:13.289503	\N	\N
tl-1790607164324	ord-1790607013291	PACKED	Admin updated status to [PACKED] with AWB: N/A	2026-09-28 14:52:44.325317	\N	\N
TL-1790607476739-KZAFE	ord-1790607476735-MAMACK	Order Confirmed	Custom WhatsApp order registered and confirmed by Store Admin.	2026-09-28 14:57:56.73579	Tiruvallur	\N
tl-cancel-1790650980839	ord-1790607476735-MAMACK	Cancelled	Cancelled prior to ST Courier dispatch	2026-09-29 03:03:00.839639	\N	\N
tl-cancel-1790651216255	ord-1790607013291	Cancelled	Reconciled via Razorpay webhook: refund.created (ID: rfnd_ThhLSkeCtDrwSL) | Razorpay refund rfnd_ThhLSkeCtDrwSL — amount returns to original payment method	2026-09-29 03:06:56.256224	\N	\N
tl-cancel-1790651250036	ord-1790490477223	Cancelled	Cancelled prior to ST Courier dispatch	2026-09-29 03:07:30.036905	\N	\N
tl-1790824972064	ord-1790824972060	Payment Confirmed	Payment verified & order finalized via webhook (ID: pay_TiUgvsfqCB4ikB)	2026-10-01 03:22:52.05878	\N	\N
tl-cancel-1790825021445	ord-1790824972060	Cancelled	Cancelled prior to ST Courier dispatch | Razorpay refund rfnd_TiUhyTBY4mmK6x — amount returns to original payment method	2026-10-01 03:23:41.446228	\N	\N
tl-1790934728651	ord-1790934728637	Payment Confirmed	Payment verified & order finalized via webhook (ID: pay_TiywY5LhsHuW2G)	2026-10-02 09:52:08.633775	\N	\N
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, order_number, user_id, address_id, subtotal, discount, shipping_charge, tax, total_amount, payment_method, payment_status, order_status, razorpay_order_id, razorpay_payment_id, razorpay_signature, shipment_id, awb_number, courier_name, tracking_url, estimated_delivery, shipping_address, packed_at, shipped_at, delivered_at, ordered_at, created_at, updated_at, coupon_code, coupon_id, idempotency_key, razorpay_refund_id, invoice_number, courier_status, order_source) FROM stdin;
ord-1790257606351	BPG-TFTZ-M1QR	usr-g-1790257137701	addr-1790257243202-89hs	1300	0	0	0	1300	Razorpay UPI	Payment Confirmed	Confirmed	order_TftZSz6UHMM8Wu	pay_TftZm1Qr3zgN62	\N	SHP-20260924-626772	\N	ST Courier Express	\N	\N	{"name":"Jo Princy","phone":"8098016112","alternatePhone":"9092052614","address":"no:13, karumarriamman Kovil Street, thuvakudi malai, trichy","city":"trichy","pincode":"620022"}	\N	\N	\N	2026-09-24 13:46:46.351	2026-09-24 13:46:46.351	2026-09-25 01:19:05.378164	\N	\N	\N	\N	BPG/26-27/00010	\N	website
ord-1790607476735-MAMACK	BPG-WA-MAMACK	wa_8248345770	\N	1	0	0	0	1	WhatsApp UPI (GPay / PhonePe / Paytm)	Cancelled	Cancelled	\N	\N	\N	SHP-20260928-MAMACK	\N	ST Courier Express	\N	\N	{"name":"Yogesh T","phone":"8248345770","alternatePhone":"8248345722","address":"Gn Chetty Street Arani\\nஜி என் செட்டி தெரு","landmark":"near petrol bunk","near_landmark":"near petrol bunk","city":"Tiruvallur","state":"Tamil Nadu","pincode":"601101","source":"whatsapp_custom_order","adminNotes":null,"shippingFee":0,"bookQty":1}	\N	\N	\N	2026-09-28 14:57:56.73579	2026-09-28 14:57:56.73579	2026-09-29 03:03:00.836422	\N	\N	custom-BPG-WA-MAMACK	\N	BPG/26-27/00013	\N	website
ord-1790490477223	BPG-FSU5JBAP	usr_1785762703802_xr7yc	\N	1	0	0	0	1	Razorpay UPI / Online	Refunded	Cancelled	order_Tgxhn9hBAPvmPg	pay_TgxhvmwvD49sUq	\N	SHP-20260927-311941	\N	ST Courier Express	\N	\N	{"id":"addr-1785763850491-qpau","city":"ARANI","name":"yogesh","type":"HOME","phone":"9360345770","state":"Tamil Nadu","address":"NO 816 GN CHETTY ST","pincode":"601101","landmark":"","isDefault":true,"alternatePhone":"9360345771"}	\N	\N	\N	2026-09-27 06:27:57.222233	2026-09-27 06:27:57.222233	2026-09-29 03:16:09.411274	\N	\N	\N	rfnd_ThhVApOh8bG7Wf	BPG/26-27/00011	\N	website
ord-1790607013291	BPG-D6LYJFA3	usr_1785762703802_xr7yc	\N	1	0	0	0	1	Razorpay UPI / Online	Refunded	Cancelled	order_ThUn9QT2rQosrO	pay_ThUnmxq28jNqQw	\N	SHP-20260928-335205	\N	ST Courier Express	https://stcourier.com	\N	{"id":"addr-1785763850491-qpau","city":"ARANI","name":"yogesh","type":"HOME","phone":"9360345770","state":"Tamil Nadu","address":"NO 816 GN CHETTY ST","pincode":"601101","landmark":"","isDefault":true,"alternatePhone":"9360345771"}	\N	\N	\N	2026-09-28 14:50:13.289503	2026-09-28 14:50:13.289503	2026-09-29 03:06:56.254434	\N	\N	\N	rfnd_ThhLSkeCtDrwSL	BPG/26-27/00012	\N	website
ord-1790824972060	BPG-YY80SOVG	usr-g-1785540503002	\N	1	0	0	0	1	Razorpay UPI / Online	Refunded	Cancelled	order_TiUgqAk37ulhyj	pay_TiUgvsfqCB4ikB	\N	SHP-20261001-994600	\N	ST Courier Express	\N	\N	{"id":"addr-1790214863225-vpfr","city":"Tiruvallur","name":"Yogesh T","type":"HOME","phone":"8248345770","state":"Tamil Nadu","address":"Gn Chetty Street Arani","pincode":"601101","landmark":"","isDefault":true,"alternatePhone":"9600219439"}	\N	\N	\N	2026-10-01 03:22:52.05878	2026-10-01 03:22:52.05878	2026-10-01 03:23:41.444376	\N	\N	\N	rfnd_TiUhyTBY4mmK6x	BPG/26-27/00017	\N	website
ord-1790934728637	BPG-SAOQLYGH	usr-g-1785540503002	addr-1790214863225-vpfr	2	0	0	0	2	Razorpay UPI / Online	Payment Confirmed	Confirmed	order_Tiyw0nFJjtpRxp	pay_TiywY5LhsHuW2G	\N	SHP-20261002-705416	\N	ST Courier Express	\N	\N	{"city":"Tamil Nadu","name":"YOGESH 👊","address":"No 860 gn chetty st arani,Thiruvallur-601101","pincode":"601101","email":"","phone":"8248345770"}	\N	\N	\N	2026-10-02 09:52:08.633775	2026-10-02 09:52:08.633775	2026-10-02 09:52:08.633775	\N	\N	\N	\N	BPG/26-27/00018	\N	whatsapp
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (phone, code, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, order_id, payment_gateway, payment_id, transaction_id, amount, currency, status, paid_at, updated_at) FROM stdin;
pay-1790490477227	ord-1790490477223	Razorpay	pay_TgxhvmwvD49sUq	order_Tgxhn9hBAPvmPg	1	INR	REFUNDED	2026-09-27 06:27:57.222233	2026-10-02 10:48:13.512096
pay-orphan-1786170183541	\N	Razorpay	pay_TNAus8bxqhFj1t	order_TNAuiLoxOa2oep	1110	INR	REFUNDED	2026-08-08 06:23:03.541606	2026-10-02 10:48:13.512096
pay-1790824972063	ord-1790824972060	Razorpay	pay_TiUgvsfqCB4ikB	order_TiUgqAk37ulhyj	1	INR	REFUNDED	2026-10-01 03:22:52.05878	2026-10-02 10:48:13.512096
pay-1790934728649	ord-1790934728637	Razorpay	pay_TiywY5LhsHuW2G	order_Tiyw0nFJjtpRxp	2	INR	SUCCESS	2026-10-02 09:52:08.633775	2026-10-02 10:48:13.512096
pay-orphan-1790257606351	ord-1790257606351	Razorpay	pay_TftZm1Qr3zgN62	order_TftZSz6UHMM8Wu	1300	INR	SUCCESS	2026-09-24 13:46:46.351705	2026-10-02 10:48:13.512096
pay-1790607013294	ord-1790607013291	Razorpay	pay_ThUnmxq28jNqQw	order_ThUn9QT2rQosrO	1	INR	REFUNDED	2026-09-28 14:50:13.289503	2026-10-02 10:48:13.512096
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_limits (key, count, reset_at) FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refunds (id, order_id, razorpay_refund_id, razorpay_payment_id, amount, status, reason, created_at) FROM stdin;
ref-1790651216251-36se	ord-1790607013291	rfnd_ThhLSkeCtDrwSL	pay_ThUnmxq28jNqQw	1	PROCESSED	Reconciled via Razorpay webhook: refund.created (ID: rfnd_ThhLSkeCtDrwSL)	2026-09-29 03:06:56.251647
ref-manual-fix-001	ord-1790490477223	rfnd_ThhVApOh8bG7Wf	pay_TgxhvmwvD49sUq	1	PROCESSED	Admin cancel refund	2026-09-29 03:16:09.415122
ref-1790825021441-s25r	ord-1790824972060	rfnd_TiUhyTBY4mmK6x	pay_TiUgvsfqCB4ikB	1	PENDING	Cancelled prior to ST Courier dispatch	2026-10-01 03:23:41.441852
\.


--
-- Data for Name: review_votes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_votes (id, review_id, voter_ip, created_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews (id, user_name, user_id, book_id, rating, review, created_at, order_id, images, updated_at, verified_purchase, helpful_count, district, student_class, reviewer_type) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, site_name, support_email, support_phone, razorpay_key, shipping_charge, tax_percentage, admin_alert_phones, checkout_paused, checkout_pause_message, checkout_paused_at, checkout_paused_by) FROM stdin;
main	BLESSING POWER GUIDE	blessingpowerguide@gmail.com	+91 98404 18228	\N	0	0		f	Online checkout is temporarily paused. For inquiries or book orders, please contact our support team on WhatsApp (+91-9486017820).	2026-09-27 06:21:46.88752	usr-g-1785540503002
\.


--
-- Data for Name: stock_holds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_holds (id, hold_group_id, razorpay_order_id, book_id, user_id, qty, status, expires_at, released_at, release_reason, created_at, updated_at, medium) FROM stdin;
sh-1790650303376-gcbdw1	direct-order_race_1790650303234	order_race_1790650303234	bpg-1790146297047	user_race_1790650303234	1	confirmed	2026-09-29 02:51:43.292037	\N	\N	2026-09-29 02:51:43.292037	2026-09-29 02:51:43.292037	\N
sh-1790650617278-g5obf2	direct-order_stag_b_1790650617264	order_stag_b_1790650617264	bpg-1790146297047	user_stagger_test	1	confirmed	2026-09-29 02:56:57.270994	\N	\N	2026-09-29 02:56:57.270994	2026-09-29 02:56:57.270994	\N
sh-1790606974418-p7spj9	hold-1790606974412-bqx5eb	order_ThUn9QT2rQosrO	bpg-1790146297047	usr_1785762703802_xr7yc	1	released	2026-09-28 15:09:34.412463	2026-09-29 03:06:56.261525	cancel:Reconciled via Razorpay webhook: refund.created (ID: rfnd_ThhLSkeCtDrwSL)	2026-09-28 14:49:34.412463	2026-09-29 03:06:56.261525	Tamil Medium
sh-1790257557323-cm4xx1	hold-1790257557319-slp0fw	order_TftZSz6UHMM8Wu	bpg-1790146297047	usr-g-1790257137701	1	confirmed	2026-09-24 14:05:57.319433	\N	\N	2026-09-24 13:45:57.319433	2026-09-24 13:46:46.345277	\N
sh-1790824956028-n7stg3	hold-1790824956027-5ao18x	order_TiUgqAk37ulhyj	bpg-1790146297047	usr-g-1785540503002	1	released	2026-10-01 03:42:36.027529	2026-10-01 03:23:41.452746	cancel:Cancelled prior to ST Courier dispatch	2026-10-01 03:22:36.027529	2026-10-01 03:23:41.452746	Tamil Medium
sh-1790650616056-rmifu0	direct-order_stag_a_1790650616036	order_stag_a_1790650616036	bpg-1790146297047	user_stagger_test	1	confirmed	2026-09-29 02:56:56.049085	\N	\N	2026-09-29 02:56:56.049085	2026-09-29 02:56:56.049085	\N
sh-1790664888790-8h5kle	hold-1790664888786-s4leo2	order_ThlElabiqDa3aA	bpg-1790146297047	usr-g-1785834276184	1	released	2026-09-29 07:14:48.78688	2026-09-29 06:54:53.568247	modal_dismissed	2026-09-29 06:54:48.78688	2026-09-29 06:54:53.568247	Tamil Medium
sh-1790934728648-12kvv8	direct-order_Tiyw0nFJjtpRxp	order_Tiyw0nFJjtpRxp	bpg-1790146297047	wa-8248345770	2	confirmed	2026-10-02 09:52:08.633775	\N	\N	2026-10-02 09:52:08.633775	2026-10-02 09:52:08.633775	\N
\.


--
-- Data for Name: support_conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_conversations (id, customer_id, session_token, customer_name, customer_phone, order_id, status, assigned_admin_id, assigned_admin_name, accepted_at, resolved_at, last_message_at, created_at, updated_at, last_admin_activity_at) FROM stdin;
conv_1789750553626_6f666020	usr-g-1786000184052	6a22e441751840f1ac577e7343765ab0	Yogesh	9842348340	\N	RESOLVED	\N	\N	\N	2026-09-18 16:56:08.060533	2026-09-18 16:55:53.632473	2026-09-18 16:55:53.627243	2026-09-18 16:56:08.060533	\N
conv_1790924335211_c0aedfe7	\N	852d0499d98bac0a814ad377bcf31b1e	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-10-02 06:59:00.247588	2026-10-02 06:58:55.213249	2026-10-02 06:59:00.247588	\N
conv_1789265022397_d1b51dfd	usr_1785762703802_xr7yc	390d28e38684c24b7024e7f6fc6d3f1d	Yogesh T	919360345770	BPG-WHTB22KK	RESOLVED	\N	\N	\N	2026-09-13 02:04:18.750766	2026-09-13 02:03:46.834084	2026-09-13 02:03:42.397756	2026-09-13 02:04:18.750766	\N
conv_1789750569442_6d4b8cae	usr-g-1786000184052	6c0dcf83b11f9a6df4bfbc27d9493b0b	Yogesh	9842348340	\N	RESOLVED	\N	\N	\N	2026-09-18 16:56:10.256671	2026-09-18 16:56:09.442691	2026-09-18 16:56:09.442691	2026-09-18 16:56:10.256671	\N
conv_1789750570258_a8aa8cc5	usr-g-1786000184052	f2ebf0ac0d8e45d4ef47741196bc60fd	Yogesh	9842348340	\N	RESOLVED	\N	\N	\N	2026-09-18 16:56:11.073393	2026-09-18 16:56:10.258839	2026-09-18 16:56:10.258839	2026-09-18 16:56:11.073393	\N
conv_1789750571075_28091758	usr-g-1786000184052	8b3d9ad00dad3c19afba3d193a9e5c55	Yogesh	9842348340	\N	RESOLVED	\N	\N	\N	2026-09-18 16:56:13.784135	2026-09-18 16:56:11.075401	2026-09-18 16:56:11.075401	2026-09-18 16:56:13.784135	\N
conv_1789265062086_b2763027	usr_1785762703802_xr7yc	3cf9c4a4d81da0c1f4f1eadef9f8eda3	Yogesh T	919360345770	\N	RESOLVED	\N	\N	\N	2026-09-13 02:13:10.619774	2026-09-13 02:12:22.972798	2026-09-13 02:04:22.086713	2026-09-13 02:13:10.619774	\N
conv_1789265591889_012364d7	usr_1785762703802_xr7yc	4da28b2ffd14a668f6335c2ffb14951b	Yogesh T	919360345770	\N	RESOLVED	usr-g-1785540503002	YOGESH	2026-09-13 02:13:41.839674	2026-09-13 02:17:09.773415	2026-09-13 02:13:29.759057	2026-09-13 02:13:11.890289	2026-09-13 02:17:09.773415	2026-09-13 02:13:41.839674
conv_1789750573785_91cdb195	usr-g-1786000184052	f54215b90486870245e04ca195d66820	Yogesh	9842348340	\N	RESOLVED	\N	\N	2026-09-19 06:47:59.771154	2026-09-19 08:13:49.906721	2026-09-19 08:12:01.598611	2026-09-18 16:56:13.786146	2026-09-19 08:13:49.906721	2026-09-19 06:48:25.29003
conv_1789805631257_77f7c901	usr-g-1786000184052	53cc7ba5945593383ea13559054d5718	Yogesh	9842348340	\N	RESOLVED	usr-g-1785540503002	YOGESH	2026-09-19 09:44:43.669041	2026-09-19 09:45:05.233355	2026-09-19 09:44:54.492055	2026-09-19 08:13:51.257861	2026-09-19 09:45:05.233355	2026-09-19 09:44:54.492055
conv_1789350226657_65798ff8	\N	2657a95cdba7c90bf46d8d6050e002d1	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-09-14 01:43:46.66406	2026-09-14 01:43:46.658087	2026-09-14 01:43:46.66406	\N
conv_1789465905201_9743dbf4	\N	fe03d875cbcdf2e4638b0d1a231a684b	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-09-15 09:51:52.616746	2026-09-15 09:51:45.201478	2026-09-15 09:51:52.616746	\N
conv_1789811107133_53a2675f	usr-g-1786000184052	d4498a99eab93af84957ec87600f7d70	Yogesh	9842348340	\N	RESOLVED	usr-g-1785540503002	YOGESH	2026-09-20 07:10:52.162606	2026-09-20 07:11:14.966785	2026-09-20 07:10:57.661538	2026-09-19 09:45:07.133585	2026-09-20 07:11:14.966785	2026-09-20 07:10:57.661538
conv_1789888276322_f66cc166	usr-g-1786000184052	59b8a0fc1762c52828a15ec97b6a34ff	Yogesh	9842348340	\N	BOT	\N	\N	\N	\N	2026-09-20 07:11:16.322584	2026-09-20 07:11:16.322584	2026-09-20 07:11:16.322584	\N
conv_1789265831035_fcd1f818	usr_1785762703802_xr7yc	3fd69d505bcd00a2b62ee3d502ced7f1	Yogesh T	919360345770	\N	RESOLVED	usr-g-1786000184052	Yogesh	2026-09-16 08:22:13.180545	2026-09-16 08:27:57.571944	2026-09-16 08:23:18.45653	2026-09-13 02:17:11.036121	2026-09-16 08:27:57.571944	2026-09-16 08:22:55.919285
conv_1789547019307_e7beaf92	usr_1785762703802_xr7yc	1060954b8a2de854f6eb4807e80d4730	Yogesh T	919360345770	\N	RESOLVED	\N	\N	\N	2026-09-16 08:27:58.848644	2026-09-16 08:23:39.308081	2026-09-16 08:23:39.308081	2026-09-16 08:27:58.848644	\N
conv_1789547278850_0b769ebe	usr_1785762703802_xr7yc	bb2b6a930a33967a23ae213563057eda	Yogesh T	919360345770	\N	BOT	\N	\N	\N	\N	2026-09-16 08:27:58.850538	2026-09-16 08:27:58.850538	2026-09-16 08:27:58.850538	\N
conv_1789644768084_6a5cdf5c	\N	8ced9bc0a0773b4c024f1a246af77b49	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-09-17 11:32:48.091132	2026-09-17 11:32:48.084855	2026-09-17 11:32:48.091132	\N
conv_1789921560970_9b044566	\N	41c513dc5777184462af485a4f703c05	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-09-20 16:26:00.975499	2026-09-20 16:26:00.970665	2026-09-20 16:26:00.975499	\N
conv_1790064496006_b5203484	usr-g-1785834276184	8b9d1fbada554b537809c6d69593f4ed	YOGESH T	8248345779	\N	BOT	\N	\N	\N	\N	2026-09-22 08:08:16.014861	2026-09-22 08:08:16.007102	2026-09-22 08:08:16.014861	\N
conv_1789998890157_5e3c4612	\N	5f392a28e955015a95856c5d8a2ff9e6	Customer	\N	\N	RESOLVED	\N	\N	\N	2026-09-22 12:55:44.032044	2026-09-21 13:55:14.054882	2026-09-21 13:54:50.157885	2026-09-21 13:55:14.054882	\N
conv_1790042228451_e03deb26	usr-g-1790042184874	7d97001c2ddc016dc9b2c85d58cb4237	Murugan Saritha	9047715492	\N	RESOLVED	\N	\N	\N	2026-09-22 12:55:44.032044	2026-09-22 01:57:20.787537	2026-09-22 01:57:08.451448	2026-09-22 01:57:20.787537	\N
conv_1790079688568_88caea71	\N	548d1da68087e9ee9b17127663e5ff48	Customer	\N	\N	RESOLVED	\N	\N	\N	2026-09-22 12:55:44.032044	2026-09-22 12:21:28.574541	2026-09-22 12:21:28.568957	2026-09-22 12:21:28.574541	\N
conv_1790101057969_62fdd18e	\N	98725f24e0c72b28b53e74ea91e881bc	Customer	\N	\N	BOT	\N	\N	\N	\N	2026-09-22 18:17:37.97501	2026-09-22 18:17:37.969972	2026-09-22 18:17:37.97501	\N
conv_1790396168492_aac1e786	usr-g-1790395716391	21ee4f39ea005997c7d15f2ad0830f92	NAVEEN BALAJI S	8925123361	\N	RESOLVED	usr-g-1785540503002	YOGESH	2026-09-26 04:16:32.522027	2026-09-26 04:17:35.524369	2026-09-26 04:17:13.244193	2026-09-26 04:16:08.492847	2026-09-26 04:17:35.524369	2026-09-26 04:17:13.244193
conv_1790396256941_32138297	usr-g-1790395716391	d44278122f03d241cb698c1d37345e43	NAVEEN BALAJI S	8925123361	\N	RESOLVED	\N	\N	\N	2026-09-26 04:18:02.444807	2026-09-26 04:17:36.941887	2026-09-26 04:17:36.941887	2026-09-26 04:18:02.444807	\N
conv_1790396282446_f6866b70	usr-g-1790395716391	c8479b7cb800a34425795fd673f42dd9	NAVEEN BALAJI S	8925123361	\N	BOT	\N	\N	\N	\N	2026-09-26 04:18:02.447631	2026-09-26 04:18:02.447631	2026-09-26 04:18:02.447631	\N
\.


--
-- Data for Name: support_feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_feedback (id, conversation_id, customer_name, admin_id, admin_name, rating, tags, comment, created_at) FROM stdin;
fb_1789265590617_af64d3	conv_1789265062086_b2763027	Yogesh T	ai_bot	Blessing AI Assistant	5	Quick Solution		2026-09-13 02:13:10.617421
fb_1789265829771_4b117a	conv_1789265591889_012364d7	Yogesh T	usr-g-1785540503002	YOGESH	2		very worst	2026-09-13 02:17:09.771664
fb_1789547017931_7c8977	conv_1789265831035_fcd1f818	Yogesh T	usr-g-1786000184052	Yogesh	5			2026-09-16 08:23:37.932396
fb_1789805629903_a7d792	conv_1789750573785_91cdb195	Yogesh	\N	Chennai Support Team	5	Quick Solution		2026-09-19 08:13:49.904256
fb_1789811105230_ac8410	conv_1789805631257_77f7c901	Yogesh	usr-g-1785540503002	YOGESH	3	Helpful Details		2026-09-19 09:45:05.231113
fb_1789888274964_370dad	conv_1789811107133_53a2675f	Yogesh	usr-g-1785540503002	YOGESH	1		not good	2026-09-20 07:11:14.965043
fb_1790396255522_60afca	conv_1790396168492_aac1e786	NAVEEN BALAJI S	usr-g-1785540503002	YOGESH	5	Friendly Staff		2026-09-26 04:17:35.522355
\.


--
-- Data for Name: support_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_messages (id, conversation_id, sender_type, sender_name, sender_id, text, is_read, read_at, created_at, metadata, client_message_id) FROM stdin;
msg_1789265022400_3999a6c2	conv_1789265022397_d1b51dfd	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	🚚 Where is my order right now?	f	\N	2026-09-13 02:03:42.400317	\N	msg_c_1789265019467_ew5sgjt
msg_1789265022460_ai	conv_1789265022397_d1b51dfd	AI	Blessing AI Assistant	\N	Hello **Yogesh T**! Here is your order **#BPG-WHTB22KK**:\n\n• **Current Status**: **PACKED**\n• **Customer**: yogesh\n• **Destination**: ARANI (601101)\n• **Total Paid**: ₹1400 (Prepaid via Razorpay)\n\n⏳ **Packaging in Progress**: Our Chennai packaging hub is preparing your order. Your books will be handed over to ST Courier Express today. An SMS with your official ST Courier docket tracking link will be sent to 9360345770.\n\n📚 **Guides in this package**:\n• 10TH TAMIL GUIDE (×5)	f	\N	2026-09-13 02:03:42.410532	{"cardType": "order", "suggestions": ["📍 View Live Tracking", "📄 Download Tax Invoice", "🔄 Report Damaged Book", "👨‍💼 Talk to Admin"], "linkedOrderData": {"city": "ARANI", "items": [{"qty": 5, "price": 280, "title": "10TH TAMIL GUIDE"}], "status": "PACKED", "orderId": "BPG-WHTB22KK", "pincode": "601101", "courierName": "ST Courier Express", "totalAmount": 1400, "trackingUrl": "https://stcourier.com", "trackingNumber": null}}	\N
msg_1789265026832_0dbb27f2	conv_1789265022397_d1b51dfd	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📍 Can I update my delivery phone number?	f	\N	2026-09-13 02:03:46.832584	\N	msg_c_1789265023903_53c8btz
msg_1789265026887_ai	conv_1789265022397_d1b51dfd	AI	Blessing AI Assistant	\N	✏️ **Update Delivery Address or Mobile Number**:\n\nIf your parcel has not yet been scanned and picked up by ST Courier Express, our team can update your shipping label immediately.\n\nClick **Connect to Admin Now** so our warehouse staff can update your delivery phone number or address before dispatch.	f	\N	2026-09-13 02:03:46.837912	{"cardType": "contact", "suggestions": ["👨‍💼 Connect to Admin Now", "📞 Call Office Directly (+91 98404 18228)", "💬 WhatsApp Helpline", "🚚 Track Order"]}	\N
msg_1789265062088_welcome	conv_1789265062086_b2763027	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-13 02:04:22.088338	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789265517755_d8ea355a	conv_1789265062086_b2763027	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📦 Replacement for damaged or misprinted guide	f	\N	2026-09-13 02:11:57.756169	\N	msg_c_1789265514820_tgzoceg
msg_1789265517814_ai	conv_1789265062086_b2763027	AI	Blessing AI Assistant	\N	🛡️ **100% Free Replacement Guarantee**:\n\nWe provide a 100% Free Replacement Guarantee for any misprinted, missing pages, or transit-damaged guides. A fresh copy is dispatched immediately via ST Courier at zero extra cost.\n\nIf your parcel arrived damaged in transit or has any printing defect, please click **Connect to Admin Now** below or send a photo of the parcel/book to our WhatsApp helpline at **+91 98404 18228**. Our Chennai dispatch office will send a fresh copy immediately.	f	\N	2026-09-13 02:11:57.764793	{"cardType": "contact", "suggestions": ["👨‍💼 Talk to Admin", "📞 Call Helpline (+91 98404 18228)", "💬 WhatsApp Support", "🚚 Track Order"]}	\N
msg_1789265527073_6d6b8faa	conv_1789265062086_b2763027	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📦 Replacement for damaged or misprinted guide	f	\N	2026-09-13 02:12:07.074225	\N	msg_c_1789265524144_269fxn4
msg_1789265527130_ai	conv_1789265062086_b2763027	AI	Blessing AI Assistant	\N	🛡️ **100% Free Replacement Guarantee**:\n\nWe provide a 100% Free Replacement Guarantee for any misprinted, missing pages, or transit-damaged guides. A fresh copy is dispatched immediately via ST Courier at zero extra cost.\n\nIf your parcel arrived damaged in transit or has any printing defect, please click **Connect to Admin Now** below or send a photo of the parcel/book to our WhatsApp helpline at **+91 98404 18228**. Our Chennai dispatch office will send a fresh copy immediately.	f	\N	2026-09-13 02:12:07.080918	{"cardType": "contact", "suggestions": ["👨‍💼 Talk to Admin", "📞 Call Helpline (+91 98404 18228)", "💬 WhatsApp Support", "🚚 Track Order"]}	\N
msg_1789265532080_7f5b9e1a	conv_1789265062086_b2763027	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📍 Can I update my delivery phone number?	f	\N	2026-09-13 02:12:12.081589	\N	msg_c_1789265529130_djtg5s2
msg_1789265532140_ai	conv_1789265062086_b2763027	AI	Blessing AI Assistant	\N	✏️ **Update Delivery Address or Mobile Number**:\n\nIf your parcel has not yet been scanned and picked up by ST Courier Express, our team can update your shipping label immediately.\n\nClick **Connect to Admin Now** so our warehouse staff can update your delivery phone number or address before dispatch.	f	\N	2026-09-13 02:12:12.09123	{"cardType": "contact", "suggestions": ["👨‍💼 Talk to Admin", "📞 Call Office Directly (+91 98404 18228)", "💬 WhatsApp Helpline", "🚚 Track Order"]}	\N
msg_1789265542970_d48ea581	conv_1789265062086_b2763027	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📚 What guides are available for 10th standard?	f	\N	2026-09-13 02:12:22.970833	\N	msg_c_1789265540041_5qfedqu
msg_1789265543030_ai	conv_1789265062086_b2763027	AI	Blessing AI Assistant	\N	📚 **Class 10 Guides & Prices**:\n\n• **10th Tamil Guide** — ₹260\n• **10th English Guide** — ₹260\n• **10th Mathematics Guide** — ₹280\n• **10th Science Guide** — ₹280\n• **10th Social Science Guide** — ₹280\n• **🌟 10th All-in-One Full Set Combo (5 Books)** — Unlocks Free Delivery!\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:12:22.981207	{"cardData": [], "cardType": "books", "suggestions": ["🛒 View 10th Full Set (5 Books - Free Delivery)", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789265590621_sys	conv_1789265062086_b2763027	SYSTEM	System	\N	⭐ Customer submitted feedback (5/5 stars). Ticket resolved.	f	\N	2026-09-13 02:13:10.622179	\N	\N
msg_1789265591891_welcome	conv_1789265591889_012364d7	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-13 02:13:11.892025	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789265609760_sys	conv_1789265591889_012364d7	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-13 02:13:29.760953	\N	\N
msg_1789265621841_sys	conv_1789265591889_012364d7	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-13 02:13:41.841675	\N	\N
msg_1789265621863_adm	conv_1789265591889_012364d7	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-13 02:13:41.843501	\N	\N
msg_1789265809920_sys	conv_1789265591889_012364d7	SYSTEM	System	\N	Chat ended by admin (Yogesh). How was your experience?	f	\N	2026-09-13 02:16:49.921116	\N	\N
msg_1789265829775_sys	conv_1789265591889_012364d7	SYSTEM	System	\N	⭐ Customer submitted feedback (2/5 stars). Ticket resolved.	f	\N	2026-09-13 02:17:09.775748	\N	\N
msg_1789265831039_welcome	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-13 02:17:11.039846	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789266668151_eacbf7c0	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	What payment methods do you support and is cash on delivery available?	f	\N	2026-09-13 02:31:08.151932	\N	msg_c_1789266665209_7wk0vqm
msg_1789266668215_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	💳 **Payment Options & COD Policy**:\n\n• **Supported Online Payments**: Prepaid online via Razorpay (UPI, Google Pay, PhonePe, Paytm, BHIM, RuPay, Visa, MasterCard, NetBanking). Cash on Delivery (COD) is not supported to ensure safe, moisture-proof educational delivery.\n• **Cash on Delivery (COD)**: We do **not** offer Cash on Delivery. Educational textbooks are packaged in special protective wrappers that cannot be kept in open transit. Online prepaid orders receive priority same-day packaging, instant SMS confirmation, and live ST Courier tracking.	f	\N	2026-09-13 02:31:08.165856	{"cardType": "policy", "suggestions": ["📦 How to Place Order", "📚 View 10th Full Set", "🛡️ Is Payment Safe?", "👨‍💼 Talk to Admin"]}	\N
msg_1789266686024_e5cf4b27	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	How can I get free shipping on my order?	f	\N	2026-09-13 02:31:26.025059	\N	msg_c_1789266683085_9o0udvv
msg_1789266686085_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	🚚 **Shipping & Delivery Rates**:\n\n• **4 Books (MOQ)**: ₹150 flat delivery fee across Tamil Nadu.\n• **5 or more Books**: **100% FREE DOORSTEP DELIVERY (₹0 shipping)**!\n• **Delivery Partner**: ST Courier Express (Direct daily dispatch from Chennai Central Packaging Hub).\n• **Transit Times**:\n  - Chennai & suburbs: **24 to 48 hours**\n  - Rest of Tamil Nadu (Coimbatore, Madurai, Trichy, Salem, Tirunelveli, Erode, etc.): **2 to 3 business days**\n\n🎯 *Pro Tip: Buying the complete 10th set (5 subjects) gives you free shipping automatically!*	f	\N	2026-09-13 02:31:26.03568	{"cardType": "policy", "suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Delivery Timelines", "👨‍💼 Talk to Admin", "📞 Helpline"]}	\N
msg_1789266692480_623e91c3	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	Where is your Chennai office and what are your working hours?	f	\N	2026-09-13 02:31:32.480831	\N	msg_c_1789266689549_6noeq5x
msg_1789266692536_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	⏱️ **ST Courier Delivery Timelines**:\n\n• **Chennai, Chengalpattu & Tiruvallur**: 24 to 48 hours for Chennai, Chengalpattu & Tiruvallur.\n• **All Other Tamil Nadu Districts**: 2 to 3 business days across other Tamil Nadu districts (Coimbatore, Madurai, Trichy, Salem, Tirunelveli, Erode, Vellore, Thanjavur, etc.).\n• **Other South Indian States**: 3 to 5 business days for other South Indian locations.\n\nAll parcels are packed in tamper-evident, water-resistant packaging and scanned onto daily express ST Courier vans. Live SMS updates are sent with your official tracking docket.	f	\N	2026-09-13 02:31:32.486452	{"suggestions": ["🚚 Track My Order", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789266748604_8bfe118c	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	What guides are available for 10th standard and what are the prices?	f	\N	2026-09-13 02:32:28.604743	\N	msg_c_1789266745672_z29epae
msg_1789266748666_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:28.617062	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266758423_fe24ce35	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	How do I buy the 10th Complete Full Set of 5 books?	f	\N	2026-09-13 02:32:38.423936	\N	msg_c_1789266755486_lr77931
msg_1789266758484_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:38.434622	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266759814_c98cc0a2	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	How do I buy the 10th Complete Full Set of 5 books?	f	\N	2026-09-13 02:32:39.814293	\N	msg_c_1789266756883_yz5cmsk
msg_1789266759869_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:39.820077	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266760384_d4f15e26	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	How do I buy the 10th Complete Full Set of 5 books?	f	\N	2026-09-13 02:32:40.384319	\N	msg_c_1789266757450_li5k2x1
msg_1789887050507_15580ec1	conv_1789811107133_53a2675f	CUSTOMER	Yogesh	usr-g-1786000184052	👨‍💼 Talk to an admin	f	\N	2026-09-20 06:50:50.508148	\N	msg_c_1789887050053_5gea36w
msg_1789266760440_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:40.39025	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266761222_b40e1958	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	How do I buy the 10th Complete Full Set of 5 books?	f	\N	2026-09-13 02:32:41.222867	\N	msg_c_1789266758288_1m4dk08
msg_1789266761278_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:41.22848	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266769218_5034eddd	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📚 Browse Books Catalog	f	\N	2026-09-13 02:32:49.218681	\N	msg_c_1789266766284_xpa3itf
msg_1789266769279_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:49.22962	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789266776353_c2c87de4	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	🚚 Check Delivery Timelines	f	\N	2026-09-13 02:32:56.353222	\N	msg_c_1789266773423_qn30ge2
msg_1789266776412_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	⏱️ **ST Courier Delivery Timelines**:\n\n• **Chennai, Chengalpattu & Tiruvallur**: 24 to 48 hours for Chennai, Chengalpattu & Tiruvallur.\n• **All Other Tamil Nadu Districts**: 2 to 3 business days across other Tamil Nadu districts (Coimbatore, Madurai, Trichy, Salem, Tirunelveli, Erode, Vellore, Thanjavur, etc.).\n• **Other South Indian States**: 3 to 5 business days for other South Indian locations.\n\nAll parcels are packed in tamper-evident, water-resistant packaging and scanned onto daily express ST Courier vans. Live SMS updates are sent with your official tracking docket.	f	\N	2026-09-13 02:32:56.363055	{"suggestions": ["🚚 Track My Order", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789266779892_f7c58b10	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	📚 Browse Books Catalog	f	\N	2026-09-13 02:32:59.893197	\N	msg_c_1789266776955_b1fc3rc
msg_1789266779957_ai	conv_1789265831035_fcd1f818	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-13 02:32:59.908155	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789350226661_1fcb8b4e	conv_1789350226657_65798ff8	CUSTOMER	Customer	\N	📚 What guides are available for 10th standard?	f	\N	2026-09-14 01:43:46.661766	\N	msg_c_1789350224617_kvthpir
msg_1789350226721_ai	conv_1789350226657_65798ff8	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-14 01:43:46.672232	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789465905211_149c7ccb	conv_1789465905201_9743dbf4	CUSTOMER	Customer	\N	What guides are available for 10th standard and what are the prices?	f	\N	2026-09-15 09:51:45.212884	\N	msg_c_1789465905072_i1xy0t4
msg_1789465905273_ai	conv_1789465905201_9743dbf4	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹280** ~₹350~ (20% OFF) — ✓ In Stock (103 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-15 09:51:45.224279	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "Popular", "price": "350", "stock": 103, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "280", "sample_pdf_url": null}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789465912612_6f3968d5	conv_1789465905201_9743dbf4	CUSTOMER	Customer	\N	What payment methods do you support and is cash on delivery available?	f	\N	2026-09-15 09:51:52.614596	\N	msg_c_1789465912431_bxy1ews
msg_1790101057972_5e7618ab	conv_1790101057969_62fdd18e	CUSTOMER	Customer	\N	What guides are available for 10th standard?	f	\N	2026-09-22 18:17:37.972933	\N	msg_c_1790101058101_c3xlp1k
msg_1789465912671_ai	conv_1789465905201_9743dbf4	AI	Blessing AI Assistant	\N	💳 **Payment Options & COD Policy**:\n\n• **Supported Online Payments**: Prepaid online via Razorpay (UPI, Google Pay, PhonePe, Paytm, BHIM, RuPay, Visa, MasterCard, NetBanking). Cash on Delivery (COD) is not supported to ensure safe, moisture-proof educational delivery.\n• **Cash on Delivery (COD)**: We do **not** offer Cash on Delivery. Educational textbooks are packaged in special protective wrappers that cannot be kept in open transit. Online prepaid orders receive priority same-day packaging, instant SMS confirmation, and live ST Courier tracking.	f	\N	2026-09-15 09:51:52.621346	{"cardType": "policy", "suggestions": ["📦 How to Place Order", "📚 View 10th Full Set", "🛡️ Is Payment Safe?", "👨‍💼 Talk to Admin"]}	\N
msg_1789546922146_sys	conv_1789265831035_fcd1f818	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-16 08:22:02.14682	\N	\N
msg_1789546933183_sys	conv_1789265831035_fcd1f818	SYSTEM	System	\N	🟢 Yogesh joined the chat	f	\N	2026-09-16 08:22:13.183713	\N	\N
msg_1789546933205_adm	conv_1789265831035_fcd1f818	ADMIN	Yogesh	usr-g-1786000184052	Hi! 👋 I'm Yogesh from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-16 08:22:13.185855	\N	\N
msg_1789546946458_03e6ad17	conv_1789265831035_fcd1f818	ADMIN	Yogesh	usr-g-1786000184052	hii	f	\N	2026-09-16 08:22:26.458636	\N	admin_1789546946417_u9wnrv0
msg_1789546968357_4f6b11c1	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	👨‍💼 Talk to an admin	f	\N	2026-09-16 08:22:48.357811	\N	msg_c_1789546967289_jautv3e
msg_1789546975917_d7d05887	conv_1789265831035_fcd1f818	ADMIN	Yogesh	usr-g-1786000184052	hii	f	\N	2026-09-16 08:22:55.917462	\N	admin_1789546975881_8mejrfn
msg_1789546998454_b84686d1	conv_1789265831035_fcd1f818	CUSTOMER	Yogesh T	usr_1785762703802_xr7yc	Hii	f	\N	2026-09-16 08:23:18.455099	\N	msg_c_1789546997439_9zktzd4
msg_1789547017938_sys	conv_1789265831035_fcd1f818	SYSTEM	System	\N	⭐ Customer submitted feedback (5/5 stars). Ticket resolved.	f	\N	2026-09-16 08:23:37.938919	\N	\N
msg_1789547019310_welcome	conv_1789547019307_e7beaf92	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-16 08:23:39.310396	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789547278851_welcome	conv_1789547278850_0b769ebe	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-16 08:27:58.852182	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789644768088_6b9ab097	conv_1789644768084_6a5cdf5c	CUSTOMER	Customer	\N	What are the payment options and discounts?	f	\N	2026-09-17 11:32:48.089051	\N	msg_c_1789644767823_4v6vr9f
msg_1789644768146_ai	conv_1789644768084_6a5cdf5c	AI	Blessing AI Assistant	\N	💳 **Payment Options & COD Policy**:\n\n• **Supported Online Payments**: Prepaid online via Razorpay (UPI, Google Pay, PhonePe, Paytm, BHIM, RuPay, Visa, MasterCard, NetBanking). Cash on Delivery (COD) is not supported to ensure safe, moisture-proof educational delivery.\n• **Cash on Delivery (COD)**: We do **not** offer Cash on Delivery. Educational textbooks are packaged in special protective wrappers that cannot be kept in open transit. Online prepaid orders receive priority same-day packaging, instant SMS confirmation, and live ST Courier tracking.	f	\N	2026-09-17 11:32:48.097255	{"cardType": "policy", "suggestions": ["📦 How to Place Order", "📚 View 10th Full Set", "🛡️ Is Payment Safe?", "👨‍💼 Talk to Admin"]}	\N
msg_1789750553630_cf6ef934	conv_1789750553626_6f666020	CUSTOMER	Yogesh	usr-g-1786000184052	Where is my order?	f	\N	2026-09-18 16:55:53.630469	\N	msg_c_1789750553543_saj2uo8
msg_1789750553691_ai	conv_1789750553626_6f666020	AI	Blessing AI Assistant	\N	Hello **Yogesh**! We checked your account and found no orders placed yet.\n\nWould you like to browse our Class 10 guides? All orders with 5 or more books unlock **100% Free Doorstep Delivery** anywhere in Tamil Nadu!	f	\N	2026-09-18 16:55:53.642599	{"suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Shipping & Delivery Rules", "💳 Payment Options", "👨‍💼 Talk to Admin"]}	\N
msg_1789750569444_welcome	conv_1789750569442_6d4b8cae	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-18 16:56:09.444772	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789750570260_welcome	conv_1789750570258_a8aa8cc5	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-18 16:56:10.260748	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789750571077_welcome	conv_1789750571075_28091758	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-18 16:56:11.077715	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789750573787_welcome	conv_1789750573785_91cdb195	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-18 16:56:13.788035	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789800422604_b2cec5ea	conv_1789750573785_91cdb195	CUSTOMER	Yogesh	usr-g-1786000184052	🚚 Where is my order right now?	f	\N	2026-09-19 06:47:02.605469	\N	msg_c_1789800422521_5yv3c7w
msg_1789800422719_ai	conv_1789750573785_91cdb195	AI	Blessing AI Assistant	\N	Hello **Yogesh**! We checked your account and found no orders placed yet.\n\nWould you like to browse our Class 10 guides? All orders with 5 or more books unlock **100% Free Doorstep Delivery** anywhere in Tamil Nadu!	f	\N	2026-09-19 06:47:02.670085	{"suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Shipping & Delivery Rules", "💳 Payment Options", "👨‍💼 Talk to Admin"]}	\N
msg_1789800428103_463cd2a9	conv_1789750573785_91cdb195	CUSTOMER	Yogesh	usr-g-1786000184052	📚 View 10th Full Set (5 Books - Free Delivery)	f	\N	2026-09-19 06:47:08.104425	\N	msg_c_1789800428042_uo307ul
msg_1789800428164_ai	conv_1789750573785_91cdb195	AI	Blessing AI Assistant	\N	🚚 **Shipping & Delivery Rates**:\n\n• **4 Books (MOQ)**: ₹150 flat delivery fee across Tamil Nadu.\n• **5 or more Books**: **100% FREE DOORSTEP DELIVERY (₹0 shipping)**!\n• **Delivery Partner**: ST Courier Express (Direct daily dispatch from Chennai Central Packaging Hub).\n• **Transit Times**:\n  - Chennai & suburbs: **24 to 48 hours**\n  - Rest of Tamil Nadu (Coimbatore, Madurai, Trichy, Salem, Tirunelveli, Erode, etc.): **2 to 3 business days**\n\n🎯 *Pro Tip: Buying the complete 10th set (5 subjects) gives you free shipping automatically!*	f	\N	2026-09-19 06:47:08.114689	{"cardType": "policy", "suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Delivery Timelines", "👨‍💼 Talk to Admin", "📞 Helpline"]}	\N
msg_1789800440263_2390284f	conv_1789750573785_91cdb195	CUSTOMER	Yogesh	usr-g-1786000184052	📞 Helpline	f	\N	2026-09-19 06:47:20.26519	\N	msg_c_1789800440173_lmr34h3
msg_1789800440321_ai	conv_1789750573785_91cdb195	AI	Blessing AI Assistant	\N	🏢 **Blessing Power Guide Head Office & Helpline**:\n\n• **Publication & Dispatch Office**: Trust Square, Ayanavaram, Chennai - 600012, Tamil Nadu, India\n• **Direct Phone Helpline**: **+91 98404 18228**\n• **Working Hours**: **Monday to Saturday, 9:00 AM – 8:00 PM IST**\n• **Official WhatsApp Help**: [Chat on WhatsApp](https://wa.me/919840418228) (+91 98404 18228)\n• **Courier Dispatch**: We are an official publishing house based in Chennai. All guides are packaged directly here and dispatched via ST Courier Express daily across South India.	f	\N	2026-09-19 06:47:20.271497	{"cardType": "contact", "suggestions": ["📞 Call Helpline (+91 98404 18228)", "💬 WhatsApp Support", "🚚 Track My Order", "👨‍💼 Talk to Admin"]}	\N
msg_1789800451493_sys	conv_1789750573785_91cdb195	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-19 06:47:31.493528	\N	\N
msg_1789800479772_sys	conv_1789750573785_91cdb195	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-19 06:47:59.773156	\N	\N
msg_1789800479794_adm	conv_1789750573785_91cdb195	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-19 06:47:59.775163	\N	\N
msg_1789800499958_e5f0dce3	conv_1789750573785_91cdb195	CUSTOMER	Yogesh	usr-g-1786000184052	HII	f	\N	2026-09-19 06:48:19.958795	\N	msg_c_1789800499878_cuuki2l
msg_1789800505288_3e2d9e24	conv_1789750573785_91cdb195	ADMIN	YOGESH	usr-g-1785540503002	Hi! I'm checking your order and ST Courier dispatch details right now.	f	\N	2026-09-19 06:48:25.288813	\N	admin_1789800505231_9c0s55z
msg_1789801534224_sys_requeue_pwed	conv_1789750573785_91cdb195	SYSTEM	System	\N	Re-routing to available team members	f	\N	2026-09-19 07:05:34.224968	\N	\N
msg_1789805521590_f6cfcd48	conv_1789750573785_91cdb195	CUSTOMER	Yogesh	usr-g-1786000184052	HELO	f	\N	2026-09-19 08:12:01.591	\N	msg_c_1789805521474_uc7f804
msg_1789805521812_ai	conv_1789750573785_91cdb195	AI	Blessing AI Assistant	\N	Hello **Yogesh**! I only provide verified information for Blessing Power Guide:\n\n1. 🚚 **Where is my order?** (Live ST Courier tracking & order status)\n2. 📚 **10th Class Guides & Prices** (Tamil, English, Maths, Science & Social Science)\n3. 📦 **Order Rules** (Minimum 4 books MOQ, 100% Free delivery on 5+ books)\n4. 🛡️ **100% Free Replacement** for transit-damaged or misprinted books\n5. 💳 **Razorpay Online Payments** (UPI, GPay, PhonePe, Cards)\n6. 🏢 **Chennai Head Office**: Trust Square, Ayanavaram (+91 98404 18228)\n\nFor any other questions, please click **Talk to Admin** to chat directly with our staff:	f	\N	2026-09-19 08:12:01.774735	{"suggestions": ["🚚 Track My Order", "📚 10th Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789805629910_sys	conv_1789750573785_91cdb195	SYSTEM	System	\N	⭐ Customer submitted feedback (5/5 stars). Ticket resolved.	f	\N	2026-09-19 08:13:49.91078	\N	\N
msg_1789805631259_welcome	conv_1789805631257_77f7c901	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-19 08:13:51.259785	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789811070581_8afeb1af	conv_1789805631257_77f7c901	CUSTOMER	Yogesh	usr-g-1786000184052	Where is my order?	f	\N	2026-09-19 09:44:30.58248	\N	msg_c_1789811070496_l5r7jya
msg_1789811070643_ai	conv_1789805631257_77f7c901	AI	Blessing AI Assistant	\N	Hello **Yogesh**! We checked your account and found no orders placed yet.\n\nWould you like to browse our Class 10 guides? All orders with 5 or more books unlock **100% Free Doorstep Delivery** anywhere in Tamil Nadu!	f	\N	2026-09-19 09:44:30.594141	{"suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Shipping & Delivery Rules", "💳 Payment Options", "👨‍💼 Talk to Admin"]}	\N
msg_1789811078213_sys	conv_1789805631257_77f7c901	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-19 09:44:38.213318	\N	\N
msg_1789811083671_sys	conv_1789805631257_77f7c901	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-19 09:44:43.671302	\N	\N
msg_1789811083693_adm	conv_1789805631257_77f7c901	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-19 09:44:43.673594	\N	\N
msg_1789811090532_8e660043	conv_1789805631257_77f7c901	CUSTOMER	Yogesh	usr-g-1786000184052	hi	f	\N	2026-09-19 09:44:50.533263	\N	msg_c_1789811090432_peiqqqb
msg_1789811094490_90ffb4ca	conv_1789805631257_77f7c901	ADMIN	YOGESH	usr-g-1785540503002	Hi! I'm checking your order and ST Courier dispatch details right now.	f	\N	2026-09-19 09:44:54.490442	\N	admin_1789811094388_prd6dic
msg_1789811098790_sys	conv_1789805631257_77f7c901	SYSTEM	System	\N	Chat ended by admin (YOGESH). How was your experience?	f	\N	2026-09-19 09:44:58.790402	\N	\N
msg_1789811105235_sys	conv_1789805631257_77f7c901	SYSTEM	System	\N	⭐ Customer submitted feedback (3/5 stars). Ticket resolved.	f	\N	2026-09-19 09:45:05.236124	\N	\N
msg_1789811107135_welcome	conv_1789811107133_53a2675f	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-19 09:45:07.136177	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789887041585_7a4d1229	conv_1789811107133_53a2675f	CUSTOMER	Yogesh	usr-g-1786000184052	🚚 Where is my order right now?	f	\N	2026-09-20 06:50:41.585389	\N	msg_c_1789887041127_tj2yuh9
msg_1789887041646_ai	conv_1789811107133_53a2675f	AI	Blessing AI Assistant	\N	Hello **Yogesh**! We checked your account and found no orders placed yet.\n\nWould you like to browse our Class 10 guides? All orders with 5 or more books unlock **100% Free Doorstep Delivery** anywhere in Tamil Nadu!	f	\N	2026-09-20 06:50:41.59681	{"suggestions": ["📚 View 10th Full Set (5 Books - Free Delivery)", "🚚 Shipping & Delivery Rules", "💳 Payment Options", "👨‍💼 Talk to Admin"]}	\N
msg_1789887050566_ai	conv_1789811107133_53a2675f	AI	Blessing AI Assistant	\N	I am connecting you directly with our Chennai head office support team right now. An administrator has been alerted with an audible chime and will accept your chat momentarily.\n\nOur team is available **Monday to Saturday, 9:00 AM – 8:00 PM IST**.	f	\N	2026-09-20 06:50:50.516675	{"cardType": "contact", "suggestions": ["🚚 Track My Order", "📚 Browse 10th Guides", "📞 Call Office (+91 63829 63350)"]}	\N
msg_1789887298635_sys	conv_1789811107133_53a2675f	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-20 06:54:58.635597	\N	\N
msg_1789887298657_adm	conv_1789811107133_53a2675f	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-20 06:54:58.637524	\N	\N
msg_1789887322496_37ed9252	conv_1789811107133_53a2675f	ADMIN	YOGESH	usr-g-1785540503002	hii	f	\N	2026-09-20 06:55:22.497507	\N	admin_1789887322033_wx9z6s3
msg_1789888239613_sys_requeue_0f79	conv_1789811107133_53a2675f	SYSTEM	System	\N	Re-routing to available team members	f	\N	2026-09-20 07:10:39.614173	\N	\N
msg_1789888252164_sys	conv_1789811107133_53a2675f	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-20 07:10:52.164578	\N	\N
msg_1789888252186_adm	conv_1789811107133_53a2675f	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-20 07:10:52.166589	\N	\N
msg_1789888257659_fbd3d23d	conv_1789811107133_53a2675f	ADMIN	YOGESH	usr-g-1785540503002	hello	f	\N	2026-09-20 07:10:57.659784	\N	admin_1789888257187_p6y1erc
msg_1789888264156_sys	conv_1789811107133_53a2675f	SYSTEM	System	\N	Chat ended by admin (YOGESH). How was your experience?	f	\N	2026-09-20 07:11:04.156321	\N	\N
msg_1789888274968_sys	conv_1789811107133_53a2675f	SYSTEM	System	\N	⭐ Customer submitted feedback (1/5 stars). Ticket resolved.	f	\N	2026-09-20 07:11:14.968899	\N	\N
msg_1789888276323_welcome	conv_1789888276322_f66cc166	AI	Blessing AI Assistant	\N	Hello **Yogesh**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-20 07:11:16.324171	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1789921560973_23bc6217	conv_1789921560970_9b044566	CUSTOMER	Customer	\N	What guides are available for 10th standard?	f	\N	2026-09-20 16:26:00.973585	\N	msg_c_1789921561427_v9u5gsg
msg_1789921561031_ai	conv_1789921560970_9b044566	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹20** ~₹350~ (94% OFF) — ✓ In Stock (24 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-20 16:26:00.982293	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "", "price": "350", "stock": 24, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "20", "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789998890161_54932212	conv_1789998890157_5e3c4612	CUSTOMER	Customer	\N	What guides are available for 10th standard?	f	\N	2026-09-21 13:54:50.161552	\N	msg_c_1789998889252_7rag914
msg_1789998890221_ai	conv_1789998890157_5e3c4612	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹20** ~₹350~ (94% OFF) — ✓ In Stock (24 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-21 13:54:50.171678	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "", "price": "350", "stock": 24, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "20", "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1789998914056_sys	conv_1789998890157_5e3c4612	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-21 13:55:14.056902	\N	\N
msg_1790042228454_9d4d6c70	conv_1790042228451_e03deb26	CUSTOMER	Murugan Saritha	usr-g-1790042184874	What guides are available for 10th standard?	f	\N	2026-09-22 01:57:08.454725	\N	msg_c_1790042228359_vcqr64w
msg_1790042228512_ai	conv_1790042228451_e03deb26	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹20** ~₹350~ (94% OFF) — ✓ In Stock (24 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-22 01:57:08.462379	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "", "price": "350", "stock": 24, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "20", "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1790042240789_sys	conv_1790042228451_e03deb26	SYSTEM	System	\N	⏳ Connecting you to our support team... Please wait while an agent joins.	f	\N	2026-09-22 01:57:20.789367	\N	\N
msg_1790064496011_088e18e4	conv_1790064496006_b5203484	CUSTOMER	YOGESH T	usr-g-1785834276184	📦 Replacement for damaged or misprinted guide	f	\N	2026-09-22 08:08:16.011411	\N	msg_c_1790064495717_5vzq0aq
msg_1790064496073_ai	conv_1790064496006_b5203484	AI	Blessing AI Assistant	\N	🛡️ **100% Free Replacement Guarantee**:\n\nWe provide a 100% Free Replacement Guarantee for any misprinted, missing pages, or transit-damaged guides. A fresh copy is dispatched immediately via ST Courier at zero extra cost.\n\nIf your parcel arrived damaged in transit or has any printing defect, please click **Connect to Admin Now** below or send a photo of the parcel/book to our WhatsApp helpline at **+91 94860 17820**. Our Chennai dispatch office will send a fresh copy immediately.	f	\N	2026-09-22 08:08:16.023572	{"cardType": "contact", "suggestions": ["👨‍💼 Talk to Admin", "📞 Call Helpline (+91 94860 17820)", "💬 WhatsApp Support", "🚚 Track Order"]}	\N
msg_1790079688572_06ec3451	conv_1790079688568_88caea71	CUSTOMER	Customer	\N	I want to talk to an admin.	f	\N	2026-09-22 12:21:28.572358	\N	msg_c_1790079688384_ginmtcl
msg_1790079688629_ai	conv_1790079688568_88caea71	AI	Blessing AI Assistant	\N	I am connecting you directly with our Chennai head office support team right now. An administrator has been alerted with an audible chime and will accept your chat momentarily.\n\nOur team is available **Monday to Saturday, 9:00 AM – 8:00 PM IST**.	f	\N	2026-09-22 12:21:28.579932	{"cardType": "contact", "suggestions": ["🚚 Track My Order", "📚 Browse 10th Guides", "📞 Call Office (+91 94860 17820)"]}	\N
msg_1790101058029_ai	conv_1790101057969_62fdd18e	AI	Blessing AI Assistant	\N	📚 **Official Guides Available in Store**:\n\n• **10TH TAMIL GUIDE** — **₹20** ~₹350~ (94% OFF) — ✓ In Stock (24 copies)\n\n• **Minimum Order**: 4 books (flat ₹150 courier fee)\n• **Free Delivery**: 5 or more books qualify for **100% Free Doorstep Delivery** across Tamil Nadu!\n• **Sample PDFs**: Free sample PDFs can be previewed directly on each book's page.	f	\N	2026-09-22 18:17:37.980147	{"cardData": [{"id": "bpg-1786767984265", "slug": "10th-tamil-guide-984265", "badge": "", "price": "350", "stock": 24, "title": "10TH TAMIL GUIDE", "subject": "General", "discount_price": "20", "sample_pdf_url": "/uploads/samples/sample-1789880962433-hztl1x.pdf"}], "cardType": "books", "suggestions": ["📚 Browse Books Catalog", "🚚 Check Delivery Timelines", "👨‍💼 Talk to Admin"]}	\N
msg_1790396168495_e0c5a2a7	conv_1790396168492_aac1e786	CUSTOMER	NAVEEN BALAJI S	usr-g-1790395716391	🚚 Where is my order right now?	f	\N	2026-09-26 04:16:08.495842	\N	msg_c_1790396168298_m6h4iy9
msg_1790396168555_ai	conv_1790396168492_aac1e786	AI	Blessing AI Assistant	\N	Hello **NAVEEN BALAJI S**! We checked your account and found no orders placed yet.\n\nWould you like to browse our Class 10 guides? All orders with 5 or more books unlock **100% Free Doorstep Delivery** anywhere in Tamil Nadu!	f	\N	2026-09-26 04:16:08.505998	{"suggestions": ["📚 View Combo Packs (Free Delivery)", "🚚 Shipping & Delivery Rules", "💳 Payment Options", "👨‍💼 Talk to Admin"]}	\N
msg_1790396178100_b30c7c3b	conv_1790396168492_aac1e786	CUSTOMER	NAVEEN BALAJI S	usr-g-1790395716391	👨‍💼 Talk to an admin	f	\N	2026-09-26 04:16:18.10091	\N	msg_c_1790396177840_ke475hi
msg_1790396178157_ai	conv_1790396168492_aac1e786	AI	Blessing AI Assistant	\N	I am connecting you directly with our Chennai head office support team right now. An administrator has been alerted with an audible chime and will accept your chat momentarily.\n\nOur team is available **Monday to Saturday, 9:00 AM – 8:00 PM IST**.	f	\N	2026-09-26 04:16:18.108591	{"cardType": "contact", "suggestions": ["🚚 Track My Order", "📚 Browse 10th Guides", "📞 Call Office (+91 94860 17820)"]}	\N
msg_1790396192524_sys	conv_1790396168492_aac1e786	SYSTEM	System	\N	🟢 YOGESH joined the chat	f	\N	2026-09-26 04:16:32.524544	\N	\N
msg_1790396192546_adm	conv_1790396168492_aac1e786	ADMIN	YOGESH	usr-g-1785540503002	Hi! 👋 I'm YOGESH from Blessing Power Guide Support. How can I help you?	f	\N	2026-09-26 04:16:32.526507	\N	\N
msg_1790396212460_21706d4e	conv_1790396168492_aac1e786	CUSTOMER	NAVEEN BALAJI S	usr-g-1790395716391	hii	f	\N	2026-09-26 04:16:52.46042	\N	msg_c_1790396206638_4k1obr6
msg_1790396229834_a540b508	conv_1790396168492_aac1e786	ADMIN	YOGESH	usr-g-1785540503002	Hi! I'm checking your order and ST Courier dispatch details right now.	f	\N	2026-09-26 04:17:09.83469	\N	admin_1790396229514_c2qvn1u
msg_1790396233240_9d43681b	conv_1790396168492_aac1e786	ADMIN	YOGESH	usr-g-1785540503002	Hii	f	\N	2026-09-26 04:17:13.24144	\N	admin_1790396233003_p6ux6cf
msg_1790396246887_sys	conv_1790396168492_aac1e786	SYSTEM	System	\N	Chat ended by admin (YOGESH). How was your experience?	f	\N	2026-09-26 04:17:26.887197	\N	\N
msg_1790396255526_sys	conv_1790396168492_aac1e786	SYSTEM	System	\N	⭐ Customer submitted feedback (5/5 stars). Ticket resolved.	f	\N	2026-09-26 04:17:35.526858	\N	\N
msg_1790396256943_welcome	conv_1790396256941_32138297	AI	Blessing AI Assistant	\N	Hello **NAVEEN**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-26 04:17:36.943711	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1790396282449_welcome	conv_1790396282446_f6866b70	AI	Blessing AI Assistant	\N	Hello **NAVEEN**! Welcome to your new Blessing Support session.\n\nHow can I help you today? You can check live ST Courier tracking, ask about 10th standard guides, delivery rules, or speak with an admin.	f	\N	2026-09-26 04:18:02.449932	{"suggestions": ["🚚 Where is my order right now?", "📚 10th Class Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1790924335227_0af40da9	conv_1790924335211_c0aedfe7	CUSTOMER	Customer	\N	When guid will come	f	\N	2026-10-02 06:58:55.228248	\N	msg_c_1790924334117_uczdnyr
msg_1790924335308_ai	conv_1790924335211_c0aedfe7	AI	Blessing AI Assistant	\N	Hello **Customer**! I only provide verified information for Blessing Power Guide:\n\n1. 🚚 **Where is my order?** (Live ST Courier tracking & order status)\n2. 📚 **10th Class Guides & Prices** (Tamil, English, Maths, Science & Social Science)\n3. 📦 **Order Rules** (Minimum 4 books MOQ, 100% Free delivery on 5+ books)\n4. 🛡️ **100% Free Replacement** for transit-damaged or misprinted books\n5. 💳 **Razorpay Online Payments** (UPI, GPay, PhonePe, Cards)\n    6. 🏢 **Chennai Head Office**: Trust Square, Ayanavaram (+91 94860 17820)\n\nFor any other questions, please click **Talk to Admin** to chat directly with our staff:	f	\N	2026-10-02 06:58:55.258736	{"suggestions": ["🚚 Track My Order", "📚 10th Guides & Prices", "📦 Minimum Order & Delivery Fee", "👨‍💼 Talk to Admin"]}	\N
msg_1790924340244_e283066e	conv_1790924335211_c0aedfe7	CUSTOMER	Customer	\N	🚚 Track My Order	f	\N	2026-10-02 06:59:00.244863	\N	msg_c_1790924339174_ho5rx2d
msg_1790924340301_ai	conv_1790924335211_c0aedfe7	AI	Blessing AI Assistant	\N	To check your live delivery status, I need one of these:\n\n1. Your **Order ID** (e.g. `BPG-1048` or `#1048`)\n2. Or the **10-digit mobile number** used during checkout\n3. Or your **ST Courier AWB number**\n\n💡 **Tip**: Log in to your account to see all orders automatically!	f	\N	2026-10-02 06:59:00.25241	{"suggestions": ["🚚 Where is my order?", "👨‍💼 Talk to Admin", "📚 Browse 10th Guides", "📞 Call Helpline"]}	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, phone, password_hash, google_id, profile_image, role, status, created_at, updated_at, security_question, security_answer_hash, profile_completed) FROM stdin;
usr-g-1790042184874	Murugan Saritha	murugansaritha8517@gmail.com	9047715492	786d42af051a5ae6b4157f50c4198313:f12954106f849a64c58feae86077a6e1d949581635ccae613b13ab0ae6b4804091506f5334aeac6b9cb5015a2a1f37918147fab97502dda2c14b4a32f31ffd7d	117654493466653250054	\N	customer	active	2026-09-22 01:56:24.930265	2026-09-22 01:56:35.76234	\N	\N	t
usr-g-1785834276184	YOGESH T	yogesht@student.tce.edu	8248345779	342f1733a58cff2d4ef25751362c0a92:2e68135dca4d33586b912d1dd81ff030f805b6df00cb1feeabe9d5c76fe044735c8f1e02f9b917ded77aec7b7004ba62b3ec7df40f234c42abb9a2b8e7879812	113896160478982426301	https://lh3.googleusercontent.com/a/ACg8ocKh1V8GOR2rX__kiqNk2qx126V4AsQqUkguCGEaaJSCIVTQ6w=s96-c	customer	active	2026-08-04 09:04:36.266212	2026-09-29 06:52:45.624585	\N	\N	t
usr_1788591637292_9o0z0	bhavani	bhavani@gmail.com	8680984881	fbca9dffc30c42a7b320e10271e88fe3:2907f5b85bc3f2a86db7d88d9add5e268f9ecf4d65e986c92d53b20476a8db3ae7a8ab73d30ff14c3a7ddc3d24d3437229a050079046471b31078d67e3cc2497	\N	\N	admin	active	2026-09-05 07:00:37.292376	2026-09-06 00:25:10.196538	\N	\N	t
usr-g-1788536325567	Karunyapaul	karunyapaul22@gmail.com	8525916140	293b64d042ab057ff2a16fc06f5c339d:8d79af3530f97dd9ca6fd2ef3f8215d95f9c2d9adf64fc3018c97735a5c5038f33777947fc9f21aa66088a9e662c707d67183db73c522a38d318910968b6f573	115463253587643163591	https://lh3.googleusercontent.com/a/ACg8ocJz2v3FeRf0iCLKYadwafIy7PSEhw9evvPXCGJqeRKCw6mB8II=s96-c	admin	active	2026-09-04 15:38:45.621054	2026-09-04 23:19:16.523821	\N	\N	t
usr-g-1785540503002	YOGESH	yogesh234456@gmail.com	8248345770	0cd173c552d06ab395ab5f883c7336f9:f9fb72a687777fe545fe05a4c2a9047acf68ebe6ca3b27e0738ae79bdadbc0523df99f23acc682f52590a6a2256fe3f78e8d4355ea8a8277e23986ba4b56a9ab	115598611615362633902	https://lh3.googleusercontent.com/a/ACg8ocJuPhc1ZwGMvXK0FHKaO5cX11fVKGwaFgSxS69E_lQb0g8tVA=s96-c	super_admin	active	2026-07-31 23:28:23.048796	2026-10-01 03:22:10.79381	\N	\N	t
admin-bpg-001	Admin	yt967979@gmail.com	9486017820	b013a4f9668bf3a415eb31eb766b5736:872772500237644337ad416c88a117179c4d063c519c1a2f9860ec5045dfd7d5184ef93ee68a57652058f9bb7337f8ad023ee20d3213e104f8a8bc3f25b2f3c9	\N	\N	super_admin	active	2026-08-08 06:09:59.133067	2026-09-29 03:45:06.724398	\N	\N	f
usr-g-1786000184052	Yogesh	yogeshjio5770@gmail.com	9842348340	9ce3e6a55b395815ed39305e2de54a58:6b5c895373cf526f6417a3cadaf310792c29a6a578d3d4e3772490b44922caa987ea85d79583184e369108cf7c88dca3fe4f018b0a316436f54471f9d35c3823	102193892268017515915	https://lh3.googleusercontent.com/a/ACg8ocLvlCPhfCYB1eKOYNtK2Kwo6jPDDCss7C6G7-RsQwtxV8jntA=s96-c	customer	active	2026-08-06 07:09:44.133262	2026-09-19 04:29:44.439884	\N	\N	t
usr_1785762703802_xr7yc	Yogesh T	kondruvanda@gmail.com	919360345770	d970d01afe2b454f47dae532ddc00a78:67c269d7288cb7e2afd94edc9b476965314e24c48dbef2f6281ba4873ff5cc39a685995835e3e94ab9b4ed937cd90798074a98b6f9c21b5709e8b2abbc30aed4	112254108866299306509	https://lh3.googleusercontent.com/a/ACg8ocIU3iynfFyXcuwlH8B_JH6aWpo9MpJejb7d3S5sSBg0ene6qg=s96-c	customer	active	2026-08-03 13:11:43.802523	2026-09-29 03:53:57.94765	\N	\N	t
usr-g-1786409721513	YOGESH	y9910129@gmail.com	7010196231	0260cf4e763a33b02361cee94f319262:71d2a6ef499d10313162621ea38a6e3fefff6cd12ef860c6163a520b8fc6d677088fa07bdd01a670b2363a0df38b070d325d1c097840fff503c9fc673bc3877e	117278099699623869251	https://lh3.googleusercontent.com/a/ACg8ocJTVw7gPyKcefscEaib0EQUcCm4J_AOSLH5CnRVXwmVXYsy9A=s96-c	customer	active	2026-08-11 00:55:21.568185	2026-08-11 00:55:35.150259	\N	\N	t
usr-g-1788536083512	Jeeva Blessing Tuition centre	jeevadj1111@gmail.com	8148814326	2f13c56e0743e1d11ff37257c55061ad:66e050748a32f81ab52be7bb376b2d1cf5d2fae3fcbbdc8e479ed56ab43ca9ea7a5815ec352b4fad4cd2e529da95376a6c20e654223f18ab760dadd176e8453c	109850624959683345026	https://lh3.googleusercontent.com/a/ACg8ocLxO6cxGClcmWBIu9rEMb2DFJfXzxvfElzTSVMN7lOZP9SQOvi2=s96-c	super_admin	active	2026-09-04 15:34:43.594085	2026-09-24 19:17:57.983462	\N	\N	t
usr-g-1790257137701	Jo Princy	joprincy1103@gmail.com	8098016112	05595452b1e4676ed669f56dad450bcb:7547be0561e04a75197ad94819630e6125e29810670f0158e64d2e405a027c022868124309237b4a174757a6b386ac74cc0ff712e46ea8ce30abc0595fb0322c	106863909212368601250	https://lh3.googleusercontent.com/a/ACg8ocI1ItjcblmPsPkUiCuQzd1uNhMaxJjnRCpe7gFXoffK1esklK0=s96-c	customer	active	2026-09-24 13:38:57.756616	2026-09-24 13:39:06.247812	\N	\N	t
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_events (id, event_id, event_type, payload, created_at) FROM stdin;
\.


--
-- Data for Name: whatsapp_processed_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_processed_events (event_id, event_type, processed_at) FROM stdin;
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhgWM0VCMDEzQUFFNEI4QkZGRjk4RkM0QgA=	whatsapp_message	2026-10-02 11:35:49.329306+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhgWM0VCMDM2ODA0QTgwNEYzNjg5QTM2RAA=	whatsapp_message	2026-10-02 11:36:04.084267+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhgWM0VCMDBCQkM0QzgxQUZFNzIwOUExMQA=	whatsapp_message	2026-10-02 11:36:09.695283+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhgWM0VCMDNCQkY5QTM3QjY3MzQ0RjY1OAA=	whatsapp_message	2026-10-02 11:36:20.046997+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUNBODBCODlENjQwNUZFMkU2REZCQkJFQzIyQkUxQjAA	whatsapp_message	2026-10-02 12:05:04.166243+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUNGMEQ4RjYzQkUxMUIzOEI4RjMzNkMyQzMyMUFEODEA	whatsapp_message	2026-10-02 12:05:24.252287+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUNFNjc4QTE3Qzc5OEY3ODZFQjI0ODFGMDdEQzAxNTgA	whatsapp_message	2026-10-02 12:07:30.603728+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUNFMjBGRTcyNzU0NEQ2MUYwMTJCMDM2RTg5NTEwNUEA	whatsapp_message	2026-10-02 12:07:40.562064+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUM3MjRGQTdFM0RCM0E3N0Q5NDk0RDU3QjEwMzQxMzUA	whatsapp_message	2026-10-02 12:07:45.857544+00
wamid.HBgMOTE4MjQ4MzQ1NzcwFQIAEhggQUNDNDE1ODVGQUU1MjhFMDRDNTU0MDA0OENERjg4MDMA	whatsapp_message	2026-10-02 12:52:02.389319+00
\.


--
-- Data for Name: whatsapp_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.whatsapp_sessions (phone, name, step, cart, shipping_address, razorpay_order_id, razorpay_payment_link_id, razorpay_payment_link_url, last_interaction, created_at, updated_at, email) FROM stdin;
918248345770	Yogesh T	IDLE	[{"id": "bpg-1790146297047", "qty": 2, "price": 1, "title": "10TH STD 5 IN 1 GUIDE COMBO", "medium": "Combo", "isCombo": true}]	{"city": "Tiruvallur", "name": "Yogesh T", "email": "yogesh234456@gmail.com", "phone": "8248345770", "address": "Gn Chetty Street Arani", "pincode": "601101"}	plink_TiyvwjfBQOOBWl	\N	https://rzp.io/rzp/fDEGt0V	2026-10-02 12:52:02.397728+00	2026-10-02 08:40:17.604609+00	2026-10-02 12:52:02.397728+00	yogesh234456@gmail.com
919876543210	\N	IDLE	[]	\N	\N	\N	\N	2026-10-02 11:09:57.796163+00	2026-10-02 11:09:57.794143+00	2026-10-02 11:09:57.796163+00	\N
\.


--
-- Data for Name: wishlist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wishlist (id, user_id, book_id, created_at) FROM stdin;
w-1790943259289-817	usr-g-1785540503002	bpg-1790146297047	2026-10-02 12:14:19.288427
w-1790665721904-16	usr-g-1785834276184	bpg-1790146297047	2026-09-29 07:08:41.902693
\.


--
-- Name: contact_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contact_submissions_id_seq', 8, true);


--
-- Name: review_votes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_votes_id_seq', 1, false);


--
-- Name: abandoned_carts abandoned_carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abandoned_carts
    ADD CONSTRAINT abandoned_carts_pkey PRIMARY KEY (id);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: book_images book_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book_images
    ADD CONSTRAINT book_images_pkey PRIMARY KEY (id);


--
-- Name: books books_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_pkey PRIMARY KEY (id);


--
-- Name: books books_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_slug_key UNIQUE (slug);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: cart cart_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_pkey PRIMARY KEY (id);


--
-- Name: cart cart_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_user_id_key UNIQUE (user_id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- Name: checkout_sessions checkout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_pkey PRIMARY KEY (id);


--
-- Name: checkout_sessions checkout_sessions_razorpay_order_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkout_sessions
    ADD CONSTRAINT checkout_sessions_razorpay_order_id_key UNIQUE (razorpay_order_id);


--
-- Name: contact_messages contact_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT contact_messages_pkey PRIMARY KEY (id);


--
-- Name: contact_submissions contact_submissions_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_submissions
    ADD CONSTRAINT contact_submissions_contact_id_key UNIQUE (contact_id);


--
-- Name: contact_submissions contact_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_submissions
    ADD CONSTRAINT contact_submissions_pkey PRIMARY KEY (id);


--
-- Name: coupon_redemptions coupon_redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupon_redemptions
    ADD CONSTRAINT coupon_redemptions_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_key UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: courier_tracking courier_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.courier_tracking
    ADD CONSTRAINT courier_tracking_pkey PRIMARY KEY (id);


--
-- Name: email_otps email_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_otps
    ADD CONSTRAINT email_otps_pkey PRIMARY KEY (id);


--
-- Name: failed_webhook_events failed_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_webhook_events
    ADD CONSTRAINT failed_webhook_events_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: invoice_sequences invoice_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_sequences
    ADD CONSTRAINT invoice_sequences_pkey PRIMARY KEY (financial_year);


--
-- Name: job_heartbeats job_heartbeats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_heartbeats
    ADD CONSTRAINT job_heartbeats_pkey PRIMARY KEY (job_name);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: order_timeline order_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_timeline
    ADD CONSTRAINT order_timeline_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (phone);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (key);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: review_votes review_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_votes
    ADD CONSTRAINT review_votes_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: stock_holds stock_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_holds
    ADD CONSTRAINT stock_holds_pkey PRIMARY KEY (id);


--
-- Name: support_conversations support_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_conversations
    ADD CONSTRAINT support_conversations_pkey PRIMARY KEY (id);


--
-- Name: support_feedback support_feedback_conversation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_feedback
    ADD CONSTRAINT support_feedback_conversation_id_key UNIQUE (conversation_id);


--
-- Name: support_feedback support_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_feedback
    ADD CONSTRAINT support_feedback_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: review_votes uq_review_voter; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_votes
    ADD CONSTRAINT uq_review_voter UNIQUE (review_id, voter_ip);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_event_id_key UNIQUE (event_id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_processed_events whatsapp_processed_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_processed_events
    ADD CONSTRAINT whatsapp_processed_events_pkey PRIMARY KEY (event_id);


--
-- Name: whatsapp_sessions whatsapp_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.whatsapp_sessions
    ADD CONSTRAINT whatsapp_sessions_pkey PRIMARY KEY (phone);


--
-- Name: wishlist wishlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_pkey PRIMARY KEY (id);


--
-- Name: idx_abandoned_carts_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abandoned_carts_phone ON public.abandoned_carts USING btree (phone);


--
-- Name: idx_abandoned_carts_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abandoned_carts_updated ON public.abandoned_carts USING btree (updated_at DESC);


--
-- Name: idx_abandoned_carts_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abandoned_carts_user ON public.abandoned_carts USING btree (user_id);


--
-- Name: idx_addresses_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_addresses_user_id ON public.addresses USING btree (user_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_actor ON public.audit_logs USING btree (actor_id);


--
-- Name: idx_audit_logs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_target ON public.audit_logs USING btree (target_type, target_id);


--
-- Name: idx_books_department_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_books_department_status ON public.books USING btree (department, status);


--
-- Name: idx_books_status_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_books_status_cat ON public.books USING btree (status, category_id);


--
-- Name: idx_books_status_stock; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_books_status_stock ON public.books USING btree (status, stock);


--
-- Name: idx_books_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_books_subject ON public.books USING btree (subject);


--
-- Name: idx_checkout_sessions_rzp_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checkout_sessions_rzp_order ON public.checkout_sessions USING btree (razorpay_order_id);


--
-- Name: idx_checkout_sessions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checkout_sessions_status ON public.checkout_sessions USING btree (status);


--
-- Name: idx_checkout_sessions_sweep; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checkout_sessions_sweep ON public.checkout_sessions USING btree (status, created_at);


--
-- Name: idx_checkout_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checkout_sessions_user ON public.checkout_sessions USING btree (user_id);


--
-- Name: idx_coupon_redemptions_order; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_coupon_redemptions_order ON public.coupon_redemptions USING btree (order_id);


--
-- Name: idx_coupon_redemptions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_coupon_redemptions_user ON public.coupon_redemptions USING btree (coupon_id, user_id);


--
-- Name: idx_coupons_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_coupons_code ON public.coupons USING btree (code);


--
-- Name: idx_courier_tracking_awb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_courier_tracking_awb ON public.courier_tracking USING btree (awb_number);


--
-- Name: idx_courier_tracking_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_courier_tracking_order ON public.courier_tracking USING btree (order_id);


--
-- Name: idx_failed_webhook_events_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_webhook_events_status ON public.failed_webhook_events USING btree (status);


--
-- Name: idx_notifications_user_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_read ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: idx_orders_awb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_awb ON public.orders USING btree (awb_number);


--
-- Name: idx_orders_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_created ON public.orders USING btree (ordered_at DESC);


--
-- Name: idx_orders_order_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_order_number ON public.orders USING btree (order_number);


--
-- Name: idx_orders_order_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_order_source ON public.orders USING btree (order_source);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status ON public.orders USING btree (order_status);


--
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: idx_payments_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_payment_id ON public.payments USING btree (payment_id);


--
-- Name: idx_payments_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payments_status ON public.payments USING btree (status);


--
-- Name: idx_refunds_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refunds_order_id ON public.refunds USING btree (order_id);


--
-- Name: idx_review_votes_review_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_review_votes_review_id ON public.review_votes USING btree (review_id);


--
-- Name: idx_reviews_user_book; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_reviews_user_book ON public.reviews USING btree (user_id, book_id) WHERE ((user_id IS NOT NULL) AND (book_id IS NOT NULL));


--
-- Name: idx_stock_holds_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_holds_group ON public.stock_holds USING btree (hold_group_id);


--
-- Name: idx_stock_holds_rzp_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_holds_rzp_order ON public.stock_holds USING btree (razorpay_order_id);


--
-- Name: idx_stock_holds_sweep; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stock_holds_sweep ON public.stock_holds USING btree (status, expires_at);


--
-- Name: idx_support_conv_admin_act; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_admin_act ON public.support_conversations USING btree (last_admin_activity_at DESC);


--
-- Name: idx_support_conv_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_customer ON public.support_conversations USING btree (customer_id);


--
-- Name: idx_support_conv_last_msg; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_last_msg ON public.support_conversations USING btree (last_message_at DESC);


--
-- Name: idx_support_conv_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_order ON public.support_conversations USING btree (order_id);


--
-- Name: idx_support_conv_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_session ON public.support_conversations USING btree (session_token);


--
-- Name: idx_support_conv_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_conv_status ON public.support_conversations USING btree (status);


--
-- Name: idx_support_feedback_admin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_feedback_admin ON public.support_feedback USING btree (admin_id);


--
-- Name: idx_support_feedback_rating; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_feedback_rating ON public.support_feedback USING btree (rating);


--
-- Name: idx_support_msg_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_support_msg_client_id ON public.support_messages USING btree (conversation_id, client_message_id) WHERE (client_message_id IS NOT NULL);


--
-- Name: idx_support_msg_conv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_support_msg_conv ON public.support_messages USING btree (conversation_id, created_at);


--
-- Name: idx_webhook_events_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webhook_events_event_id ON public.webhook_events USING btree (event_id);


--
-- Name: idx_whatsapp_processed_events_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_whatsapp_processed_events_time ON public.whatsapp_processed_events USING btree (processed_at);


--
-- Name: idx_whatsapp_sessions_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_whatsapp_sessions_phone ON public.whatsapp_sessions USING btree (phone);


--
-- Name: uq_orders_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_orders_idempotency_key ON public.orders USING btree (idempotency_key) WHERE ((idempotency_key IS NOT NULL) AND ((idempotency_key)::text <> ''::text));


--
-- Name: uq_orders_razorpay_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_orders_razorpay_order_id ON public.orders USING btree (razorpay_order_id) WHERE ((razorpay_order_id IS NOT NULL) AND ((razorpay_order_id)::text <> ''::text));


--
-- Name: uq_orders_razorpay_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_orders_razorpay_payment_id ON public.orders USING btree (razorpay_payment_id) WHERE ((razorpay_payment_id IS NOT NULL) AND ((razorpay_payment_id)::text <> ''::text));


--
-- Name: uq_payments_payment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_payments_payment_id ON public.payments USING btree (payment_id) WHERE ((payment_id IS NOT NULL) AND ((payment_id)::text <> ''::text));


--
-- Name: books trg_books_changed; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_books_changed AFTER INSERT OR DELETE OR UPDATE ON public.books FOR EACH ROW EXECUTE FUNCTION public.notify_books_changed();


--
-- Name: addresses addresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: book_images book_images_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.book_images
    ADD CONSTRAINT book_images_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: books books_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.books
    ADD CONSTRAINT books_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: cart_items cart_items_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: cart_items cart_items_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES public.cart(id) ON DELETE CASCADE;


--
-- Name: cart cart_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cart
    ADD CONSTRAINT cart_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_timeline order_timeline_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_timeline
    ADD CONSTRAINT order_timeline_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: refunds refunds_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: reviews reviews_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: stock_holds stock_holds_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_holds
    ADD CONSTRAINT stock_holds_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: support_feedback support_feedback_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_feedback
    ADD CONSTRAINT support_feedback_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.support_conversations(id) ON DELETE CASCADE;


--
-- Name: support_messages support_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.support_conversations(id) ON DELETE CASCADE;


--
-- Name: wishlist wishlist_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.books(id) ON DELETE CASCADE;


--
-- Name: wishlist wishlist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wishlist
    ADD CONSTRAINT wishlist_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4GknV6yGFDerkH9dWfKhdEa1pQ5MskvrDdlFo02LrRTGUfZTcodwySymuZ0qVe5

